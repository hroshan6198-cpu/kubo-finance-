export type Role = 'customer' | 'support_manager' | 'finance_admin' | 'super_admin';

export type InvoiceStatus = 'Draft' | 'Sent' | 'Paid' | 'Partially Paid' | 'Overdue' | 'Cancelled';

export type PaymentMethod = 'Bank Transfer' | 'UPI' | 'Card' | 'Cash' | 'Cheque';

export interface CompanyContact {
  companyName: string;
  contactPersonName: string;
  phoneNumber: string;
  emailAddress: string;
  updatedAt: string;
}

export interface Business {
  id: string;
  owner_id: string;
  business_name: string;
  business_type: string;
  currency: string;
  description?: string;
  website?: string;
  contact?: CompanyContact;
  created_at: string;
  updated_at: string;
}

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  phone?: string;
  business_name?: string;
  profile_edit_count: number;
  role: Role;
  created_at: string;
  updated_at: string;
}

export interface IncomeRecord {
  id: string;
  owner_id: string;
  business_id: string;
  amount: number;
  description: string;
  category: string;
  income_date: string; // YYYY-MM-DD
  created_at: string;
  updated_at: string;
}

export interface ExpenseRecord {
  id: string;
  owner_id: string;
  business_id: string;
  amount: number;
  description: string;
  category: string;
  expense_date: string; // YYYY-MM-DD
  created_at: string;
  updated_at: string;
}

export interface InvoiceItem {
  id: string;
  invoice_id: string;
  description: string;
  quantity: number;
  unit_price: number;
  amount: number;
}

export interface InvoiceRecord {
  id: string;
  owner_id: string;
  business_id: string;
  invoice_number: string;
  customer_name: string;
  customer_email?: string;
  subtotal: number;
  tax: number;
  total: number;
  issue_date: string;
  due_date: string;
  status: InvoiceStatus;
  notes?: string;
  items?: InvoiceItem[];
  created_at: string;
  updated_at: string;
}

export interface PaymentRecord {
  id: string;
  owner_id: string;
  business_id: string;
  invoice_id?: string;
  amount: number;
  payment_date: string;
  payment_method: PaymentMethod;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export type ReminderStatus =
  | 'sent'
  | 'logged'
  | 'skipped_already_updated'
  | 'skipped_already_sent'
  | 'failed_no_contact'
  | 'failed_invalid_contact'
  | 'failed_provider_error';

export interface ReminderLog {
  id: string;
  companyId: string;
  companyName: string;
  date: string; // YYYY-MM-DD
  recipient: {
    contactPersonName?: string;
    phoneNumber?: string;
    emailAddress?: string;
  };
  channel: 'SMS' | 'Email' | 'WhatsApp' | 'Multi-Channel (Demo)';
  message: string;
  status: ReminderStatus;
  sentAt: string;
  isDemo: boolean;
  notes?: string;
}

export interface DailyFinancialStatus {
  date: string; // YYYY-MM-DD
  hasIncome: boolean;
  hasExpensesOrProfit: boolean;
  isFullyUpdated: boolean;
  totalIncomeToday: number;
  totalExpenseToday: number;
  calculatedProfitToday: number;
  needsReminder: boolean;
  reminderSentToday: boolean;
  lastReminderLog?: ReminderLog;
}

export interface SchedulerRunResult {
  runAt: string;
  date: string;
  totalCompaniesChecked: number;
  remindersProcessed: number;
  skippedAlreadyUpdated: number;
  skippedAlreadySent: number;
  failedCount: number;
  logs: ReminderLog[];
}
