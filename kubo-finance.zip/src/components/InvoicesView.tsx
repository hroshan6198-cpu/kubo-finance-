import React, { useState } from 'react';
import {
  FileText,
  Plus,
  CheckCircle2,
  Clock,
  AlertCircle,
  Edit2,
  Trash2,
  CreditCard,
  Search,
  Filter,
  ArrowDownLeft,
} from 'lucide-react';
import { Business, InvoiceRecord, InvoiceStatus, PaymentRecord } from '../types';
import { EditInvoiceModal } from './EditInvoiceModal';
import { AddPaymentModal } from './AddPaymentModal';
import { ConfirmDeleteModal } from './ConfirmDeleteModal';

interface InvoicesViewProps {
  company: Business;
  invoices: InvoiceRecord[];
  payments: PaymentRecord[];
  onInvoiceCreated: () => void;
  onInvoiceUpdated: () => void;
  onInvoiceDeleted: (id: string) => void;
  onPaymentAdded: () => void;
  onPaymentDeleted: (id: string) => void;
}

export const InvoicesView: React.FC<InvoicesViewProps> = ({
  company,
  invoices,
  payments,
  onInvoiceCreated,
  onInvoiceUpdated,
  onInvoiceDeleted,
  onPaymentAdded,
  onPaymentDeleted,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [itemDesc, setItemDesc] = useState('Enterprise Consulting');
  const [subtotal, setSubtotal] = useState('50000');
  const [taxRate, setTaxRate] = useState('18');
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Modals
  const [editingInvoice, setEditingInvoice] = useState<InvoiceRecord | null>(null);
  const [deletingInvoice, setDeletingInvoice] = useState<InvoiceRecord | null>(null);
  const [isDeletingInvoice, setIsDeletingInvoice] = useState(false);

  const [isAddPaymentOpen, setIsAddPaymentOpen] = useState(false);
  const [targetInvoiceForPayment, setTargetInvoiceForPayment] = useState<string | undefined>(
    undefined,
  );
  const [deletingPayment, setDeletingPayment] = useState<PaymentRecord | null>(null);
  const [isDeletingPayment, setIsDeletingPayment] = useState(false);

  const currency = company.currency || 'INR';

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const subNum = parseFloat(subtotal);
    if (isNaN(subNum) || subNum <= 0) {
      setError('Please enter a valid subtotal amount.');
      return;
    }
    const taxNum = (subNum * (parseFloat(taxRate) || 0)) / 100;

    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/companies/${company.id}/invoices`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_name: customerName.trim(),
          customer_email: customerEmail.trim(),
          subtotal: subNum,
          tax: taxNum,
          due_date: dueDate,
          notes: 'Standard KUBO Net-15 payment terms.',
          items: [
            {
              id: `item-${Date.now()}`,
              invoice_id: '',
              description: itemDesc.trim(),
              quantity: 1,
              unit_price: subNum,
              amount: subNum,
            },
          ],
        }),
      });

      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to create invoice');
      }

      setCustomerName('');
      setCustomerEmail('');
      setShowModal(false);
      onInvoiceCreated();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveInvoiceEdit = async (
    id: string,
    data: {
      customer_name: string;
      customer_email?: string;
      subtotal: number;
      tax: number;
      due_date: string;
      status: InvoiceStatus;
      notes?: string;
    }
  ) => {
    const res = await fetch(`/api/companies/${company.id}/invoices/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const d = await res.json();
      throw new Error(d.error || 'Failed to update invoice');
    }
    onInvoiceUpdated();
  };

  const handleConfirmDeleteInvoice = async () => {
    if (!deletingInvoice) return;
    setIsDeletingInvoice(true);
    try {
      const res = await fetch(`/api/companies/${company.id}/invoices/${deletingInvoice.id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        onInvoiceDeleted(deletingInvoice.id);
        setDeletingInvoice(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsDeletingInvoice(false);
    }
  };

  const handleSavePayment = async (data: {
    amount: number;
    payment_method: string;
    invoice_id?: string;
    notes?: string;
  }) => {
    const res = await fetch(`/api/companies/${company.id}/payments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const d = await res.json();
      throw new Error(d.error || 'Failed to record payment');
    }
    onPaymentAdded();
  };

  const handleConfirmDeletePayment = async () => {
    if (!deletingPayment) return;
    setIsDeletingPayment(true);
    try {
      const res = await fetch(`/api/companies/${company.id}/payments/${deletingPayment.id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        onPaymentDeleted(deletingPayment.id);
        setDeletingPayment(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsDeletingPayment(false);
    }
  };

  const filteredInvoices = invoices.filter((inv) => {
    const matchesSearch =
      inv.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.invoice_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (inv.customer_email && inv.customer_email.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === 'ALL' || inv.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6 font-mono text-white">
      {/* Banner */}
      <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-white" />
            <h2 className="text-base font-bold tracking-tight">Invoices &amp; Accounts Receivable</h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1 font-sans">
            Client billing, accounts receivable, and payment reminders for{' '}
            <strong className="text-white font-mono">{company.business_name}</strong>.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => {
              setTargetInvoiceForPayment(undefined);
              setIsAddPaymentOpen(true);
            }}
            className="px-3.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-200 rounded transition-colors"
          >
            Record Payment
          </button>
          <button
            onClick={() => setShowModal(true)}
            className="inline-flex items-center space-x-1.5 px-4 py-1.5 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Create Invoice</span>
          </button>
        </div>
      </div>

      {/* Add Form Modal/Inline */}
      {showModal && (
        <form onSubmit={handleCreateInvoice} className="bg-black border border-zinc-700 p-5 rounded-lg space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
            <span className="font-bold uppercase tracking-wider text-white">Draft New Invoice</span>
            <button
              type="button"
              onClick={() => setShowModal(false)}
              className="text-zinc-400 hover:text-white"
            >
              Cancel
            </button>
          </div>

          {error && <div className="p-2 bg-red-950 text-red-300 rounded border border-red-800">{error}</div>}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-zinc-400 text-[10px] uppercase mb-1">Customer / Client Name *</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="e.g. Horizon Global Corp"
                required
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white focus:border-white outline-none"
              />
            </div>
            <div>
              <label className="block text-zinc-400 text-[10px] uppercase mb-1">Client Email</label>
              <input
                type="email"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                placeholder="billing@horizon.io"
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white focus:border-white outline-none"
              />
            </div>
            <div>
              <label className="block text-zinc-400 text-[10px] uppercase mb-1">Line Item Description *</label>
              <input
                type="text"
                value={itemDesc}
                onChange={(e) => setItemDesc(e.target.value)}
                placeholder="e.g. Software Architecture Milestone 1"
                required
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white focus:border-white outline-none"
              />
            </div>
            <div>
              <label className="block text-zinc-400 text-[10px] uppercase mb-1">Subtotal ({currency}) *</label>
              <input
                type="number"
                value={subtotal}
                onChange={(e) => setSubtotal(e.target.value)}
                placeholder="50000"
                required
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:border-white outline-none"
              />
            </div>
            <div>
              <label className="block text-zinc-400 text-[10px] uppercase mb-1">Tax Rate (%)</label>
              <input
                type="number"
                value={taxRate}
                onChange={(e) => setTaxRate(e.target.value)}
                placeholder="18"
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:border-white outline-none"
              />
            </div>
            <div>
              <label className="block text-zinc-400 text-[10px] uppercase mb-1">Payment Due Date</label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white focus:border-white outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={() => setShowModal(false)}
              className="px-4 py-2 border border-zinc-800 rounded text-zinc-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-white text-black font-bold rounded hover:bg-zinc-200"
            >
              {isSubmitting ? 'Generating...' : 'Issue Invoice'}
            </button>
          </div>
        </form>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-zinc-950 border border-zinc-800 p-3 rounded-lg text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search client, invoice #..."
            className="w-full bg-black border border-zinc-800 rounded pl-9 pr-3 py-1.5 text-white font-mono focus:border-white outline-none"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-zinc-500" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-black border border-zinc-800 rounded px-2.5 py-1.5 text-white font-mono text-xs focus:border-white outline-none"
          >
            <option value="ALL">All Statuses</option>
            <option value="Sent">Sent</option>
            <option value="Paid">Paid</option>
            <option value="Draft">Draft</option>
            <option value="Overdue">Overdue</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Invoices List */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
          <span className="text-xs uppercase tracking-wider text-zinc-400">
            Issued Invoices ({filteredInvoices.length})
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black text-zinc-400 text-[11px] uppercase border-b border-zinc-800">
              <tr>
                <th className="p-3.5">Invoice #</th>
                <th className="p-3.5">Client</th>
                <th className="p-3.5">Issue Date</th>
                <th className="p-3.5">Due Date</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Total</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900">
              {filteredInvoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-zinc-900/50 transition-colors">
                  <td className="p-3.5 font-mono font-bold text-white">{inv.invoice_number}</td>
                  <td className="p-3.5">
                    <div className="font-semibold text-white">{inv.customer_name}</div>
                    <div className="text-[11px] text-zinc-500 font-sans">{inv.customer_email || '—'}</div>
                  </td>
                  <td className="p-3.5 text-zinc-400 font-mono">{inv.issue_date}</td>
                  <td className="p-3.5 text-zinc-400 font-mono">{inv.due_date}</td>
                  <td className="p-3.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-sans uppercase font-medium ${
                        inv.status === 'Paid'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-900'
                          : inv.status === 'Sent'
                          ? 'bg-blue-950 text-blue-400 border border-blue-900'
                          : inv.status === 'Overdue'
                          ? 'bg-rose-950 text-rose-400 border border-rose-900'
                          : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
                      }`}
                    >
                      {inv.status}
                    </span>
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-white">
                    {currency} {Number(inv.total).toLocaleString('en-IN')}
                  </td>
                  <td className="p-3.5 text-center">
                    <div className="flex items-center justify-center space-x-1">
                      {inv.status !== 'Paid' && (
                        <button
                          onClick={() => {
                            setTargetInvoiceForPayment(inv.id);
                            setIsAddPaymentOpen(true);
                          }}
                          className="text-zinc-400 hover:text-emerald-400 p-1 rounded transition-colors"
                          title="Record Payment for Invoice"
                        >
                          <CreditCard className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        onClick={() => setEditingInvoice(inv)}
                        className="text-zinc-400 hover:text-white p-1 rounded transition-colors"
                        title="Edit Invoice"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeletingInvoice(inv)}
                        className="text-zinc-400 hover:text-rose-400 p-1 rounded transition-colors"
                        title="Delete Invoice"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {filteredInvoices.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-10 text-center text-zinc-500">
                    <p className="text-xs">No invoices found.</p>
                    <button
                      onClick={() => setShowModal(true)}
                      className="mt-3 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs rounded font-bold"
                    >
                      + Create First Invoice
                    </button>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payments Received Ledger */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ArrowDownLeft className="w-4 h-4 text-emerald-400" />
            <span className="text-xs uppercase tracking-wider text-zinc-300 font-bold">
              Payments &amp; Receipts ({payments.length})
            </span>
          </div>
          <button
            onClick={() => {
              setTargetInvoiceForPayment(undefined);
              setIsAddPaymentOpen(true);
            }}
            className="text-xs text-zinc-400 hover:text-white flex items-center space-x-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record Payment</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black text-zinc-400 text-[11px] uppercase border-b border-zinc-800">
              <tr>
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Method</th>
                <th className="p-3.5">Notes / Ref</th>
                <th className="p-3.5 text-right">Amount</th>
                <th className="p-3.5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900">
              {payments.map((p) => (
                <tr key={p.id} className="hover:bg-zinc-900/50 transition-colors">
                  <td className="p-3.5 font-mono text-zinc-300">{p.payment_date}</td>
                  <td className="p-3.5 text-zinc-300">{p.payment_method}</td>
                  <td className="p-3.5 text-zinc-400 font-sans text-[11px]">{p.notes || '—'}</td>
                  <td className="p-3.5 text-right font-mono font-bold text-emerald-400">
                    +{currency} {Number(p.amount).toLocaleString('en-IN')}
                  </td>
                  <td className="p-3.5 text-center">
                    <button
                      onClick={() => setDeletingPayment(p)}
                      className="text-zinc-500 hover:text-rose-400 p-1 rounded transition-colors"
                      title="Delete Payment Record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}

              {payments.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-zinc-500 text-xs">
                    No payment receipts logged for this company yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Invoice Modal */}
      <EditInvoiceModal
        isOpen={Boolean(editingInvoice)}
        invoice={editingInvoice}
        currency={currency}
        onClose={() => setEditingInvoice(null)}
        onSave={handleSaveInvoiceEdit}
      />

      {/* Add Payment Modal */}
      <AddPaymentModal
        isOpen={isAddPaymentOpen}
        invoices={invoices}
        currency={currency}
        defaultInvoiceId={targetInvoiceForPayment}
        onClose={() => {
          setIsAddPaymentOpen(false);
          setTargetInvoiceForPayment(undefined);
        }}
        onSave={handleSavePayment}
      />

      {/* Confirm Delete Invoice Modal */}
      <ConfirmDeleteModal
        isOpen={Boolean(deletingInvoice)}
        onClose={() => setDeletingInvoice(null)}
        onConfirm={handleConfirmDeleteInvoice}
        title="Delete this record?"
        message={`Are you sure you want to delete invoice "${deletingInvoice?.invoice_number}" for ${deletingInvoice?.customer_name}? This action cannot be undone.`}
        confirmLabel="Delete"
        cancelLabel="Cancel"
        isDeleting={isDeletingInvoice}
      />

      {/* Confirm Delete Payment Modal */}
      <ConfirmDeleteModal
        isOpen={Boolean(deletingPayment)}
        onClose={() => setDeletingPayment(null)}
        onConfirm={handleConfirmDeletePayment}
        title="Delete this record?"
        message={`Are you sure you want to delete this payment record of ${currency} ${deletingPayment?.amount?.toLocaleString('en-IN')}? This action cannot be undone.`}
        confirmLabel="Delete"
        cancelLabel="Cancel"
        isDeleting={isDeletingPayment}
      />
    </div>
  );
};
