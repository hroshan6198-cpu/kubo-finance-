import React, { useState, useEffect } from 'react';
import { X, FileText } from 'lucide-react';
import { InvoiceRecord, InvoiceStatus } from '../types';

interface EditInvoiceModalProps {
  isOpen: boolean;
  invoice: InvoiceRecord | null;
  currency: string;
  onClose: () => void;
  onSave: (
    id: string,
    data: {
      customer_name: string;
      customer_email?: string;
      subtotal: number;
      tax: number;
      due_date: string;
      status: InvoiceStatus;
      notes?: string;
    }
  ) => Promise<void>;
}

export const EditInvoiceModal: React.FC<EditInvoiceModalProps> = ({
  isOpen,
  invoice,
  currency,
  onClose,
  onSave,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [subtotal, setSubtotal] = useState('');
  const [taxRate, setTaxRate] = useState('18');
  const [dueDate, setDueDate] = useState('');
  const [status, setStatus] = useState<InvoiceStatus>('Sent');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (invoice) {
      setCustomerName(invoice.customer_name || '');
      setCustomerEmail(invoice.customer_email || '');
      setSubtotal(String(invoice.subtotal));
      const calculatedRate = invoice.subtotal > 0 ? (invoice.tax / invoice.subtotal) * 100 : 0;
      setTaxRate(String(Math.round(calculatedRate)));
      setDueDate(invoice.due_date ? invoice.due_date.split('T')[0] : '');
      setStatus(invoice.status);
      setNotes(invoice.notes || '');
    }
    setError(null);
  }, [invoice, isOpen]);

  if (!isOpen || !invoice) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const subNum = parseFloat(subtotal);
    if (isNaN(subNum) || subNum <= 0) {
      setError('Please enter a valid subtotal amount.');
      return;
    }
    if (!customerName.trim()) {
      setError('Customer name is required.');
      return;
    }
    if (!dueDate) {
      setError('Due date is required.');
      return;
    }

    const taxNum = (subNum * (parseFloat(taxRate) || 0)) / 100;

    setIsSubmitting(true);
    setError(null);

    try {
      await onSave(invoice.id, {
        customer_name: customerName.trim(),
        customer_email: customerEmail.trim(),
        subtotal: subNum,
        tax: taxNum,
        due_date: dueDate,
        status,
        notes: notes.trim(),
      });
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-zinc-950 border border-zinc-700 rounded-lg shadow-2xl p-6 font-mono text-zinc-200">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center space-x-2.5">
            <FileText className="w-5 h-5 text-zinc-300" />
            <div>
              <h3 className="font-bold text-sm tracking-wide uppercase text-white">
                Edit Invoice {invoice.invoice_number}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="text-zinc-500 hover:text-white p-1 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-2.5 bg-rose-950/50 border border-rose-800 text-rose-300 text-xs rounded">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
                Customer Name *
              </label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
              />
            </div>
            <div>
              <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
                Customer Email
              </label>
              <input
                type="email"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
                Subtotal ({currency}) *
              </label>
              <input
                type="number"
                step="any"
                required
                value={subtotal}
                onChange={(e) => setSubtotal(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
              />
            </div>
            <div>
              <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
                Tax Rate (%)
              </label>
              <input
                type="number"
                value={taxRate}
                onChange={(e) => setTaxRate(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
              />
            </div>
            <div>
              <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
                Status *
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as InvoiceStatus)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
              >
                <option value="Draft">Draft</option>
                <option value="Sent">Sent</option>
                <option value="Paid">Paid</option>
                <option value="Overdue">Overdue</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Due Date *
            </label>
            <input
              type="date"
              required
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Notes &amp; Payment Terms
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 rounded font-mono transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-white hover:bg-zinc-200 text-black font-semibold rounded font-mono transition-colors flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <span className="w-3 h-3 border-2 border-black/40 border-t-black rounded-full animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <span>Save Changes</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
