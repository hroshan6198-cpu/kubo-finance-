import React, { useState } from 'react';
import { X, CreditCard } from 'lucide-react';
import { InvoiceRecord } from '../types';

interface AddPaymentModalProps {
  isOpen: boolean;
  invoices: InvoiceRecord[];
  currency: string;
  defaultInvoiceId?: string;
  onClose: () => void;
  onSave: (data: {
    amount: number;
    payment_method: string;
    invoice_id?: string;
    notes?: string;
  }) => Promise<void>;
}

export const AddPaymentModal: React.FC<AddPaymentModalProps> = ({
  isOpen,
  invoices,
  currency,
  defaultInvoiceId,
  onClose,
  onSave,
}) => {
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Bank Transfer (NEFT/RTGS)');
  const [invoiceId, setInvoiceId] = useState(defaultInvoiceId || '');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) {
      setError('Please enter a valid payment amount.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await onSave({
        amount: num,
        payment_method: paymentMethod,
        invoice_id: invoiceId ? invoiceId : undefined,
        notes: notes.trim(),
      });
      setAmount('');
      setNotes('');
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-zinc-950 border border-zinc-700 rounded-lg shadow-2xl p-6 font-mono text-zinc-200">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center space-x-2.5">
            <CreditCard className="w-5 h-5 text-zinc-300" />
            <h3 className="font-bold text-sm tracking-wide uppercase text-white">
              Record Client Payment
            </h3>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="text-zinc-500 hover:text-white p-1 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-2.5 bg-rose-950/50 border border-rose-800 text-rose-300 text-xs rounded">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Payment Amount ({currency}) *
            </label>
            <input
              type="number"
              step="any"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="50000"
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Link to Invoice (Optional)
            </label>
            <select
              value={invoiceId}
              onChange={(e) => setInvoiceId(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            >
              <option value="">-- Direct Receipt (No Invoice) --</option>
              {invoices.map((inv) => (
                <option key={inv.id} value={inv.id}>
                  {inv.invoice_number} - {inv.customer_name} ({currency}{' '}
                  {Number(inv.total).toLocaleString()})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Payment Method *
            </label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            >
              <option value="Bank Transfer (NEFT/RTGS)">Bank Transfer (NEFT/RTGS)</option>
              <option value="UPI / Instant Pay">UPI / Instant Pay</option>
              <option value="Credit Card / Stripe">Credit Card / Stripe</option>
              <option value="Cheque Deposit">Cheque Deposit</option>
              <option value="Cash">Cash</option>
            </select>
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Reference / Transaction Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. UTR #9823417281 via HDFC Bank"
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 rounded font-mono transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-white hover:bg-zinc-200 text-black font-semibold rounded font-mono transition-colors flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <span className="w-3 h-3 border-2 border-black/40 border-t-black rounded-full animate-spin" />
                  <span>Recording...</span>
                </>
              ) : (
                <span>Record Payment</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
