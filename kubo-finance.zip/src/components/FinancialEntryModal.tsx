import React, { useState } from 'react';
import {
  X,
  TrendingUp,
  DollarSign,
  Calendar,
  Tag,
  CheckCircle2,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { Business, DailyFinancialStatus } from '../types';

interface FinancialEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  company: Business;
  financialStatus: DailyFinancialStatus | null;
  onFinancialsUpdated: () => void;
}

export const FinancialEntryModal: React.FC<FinancialEntryModalProps> = ({
  isOpen,
  onClose,
  company,
  financialStatus,
  onFinancialsUpdated,
}) => {
  const [activeMode, setActiveMode] = useState<'both' | 'income' | 'expense'>('both');

  // Income Fields
  const [incomeAmount, setIncomeAmount] = useState<string>('50000');
  const [incomeDesc, setIncomeDesc] = useState<string>("Today's Client Project Settlement");
  const [incomeCategory, setIncomeCategory] = useState<string>('Services');

  // Expense Fields (determines profit = income - expenses)
  const [expenseAmount, setExpenseAmount] = useState<string>('15000');
  const [expenseDesc, setExpenseDesc] = useState<string>("Operational & Infrastructure Costs");
  const [expenseCategory, setExpenseCategory] = useState<string>('Software');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const todayDateStr = new Date().toISOString().split('T')[0];

  const calculatedProfit =
    (parseFloat(incomeAmount) || 0) - (parseFloat(expenseAmount) || 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      // 1. Submit Income if mode is 'both' or 'income'
      if (activeMode === 'both' || activeMode === 'income') {
        const numIncome = parseFloat(incomeAmount);
        if (isNaN(numIncome) || numIncome <= 0) {
          throw new Error("Please enter a valid income amount greater than 0.");
        }

        const incomeRes = await fetch(`/api/companies/${company.id}/incomes`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            amount: numIncome,
            description: incomeDesc.trim() || 'Daily Income Record',
            category: incomeCategory,
            income_date: todayDateStr,
          }),
        });

        if (!incomeRes.ok) {
          const d = await incomeRes.json();
          throw new Error(d.error || 'Failed to record income');
        }
      }

      // 2. Submit Expense if mode is 'both' or 'expense'
      if (activeMode === 'both' || activeMode === 'expense') {
        const numExpense = parseFloat(expenseAmount);
        if (isNaN(numExpense) || numExpense <= 0) {
          throw new Error("Please enter a valid expense amount greater than 0.");
        }

        const expenseRes = await fetch(`/api/companies/${company.id}/expenses`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            amount: numExpense,
            description: expenseDesc.trim() || 'Daily Operating Expense',
            category: expenseCategory,
            expense_date: todayDateStr,
          }),
        });

        if (!expenseRes.ok) {
          const d = await expenseRes.json();
          throw new Error(d.error || 'Failed to record expense');
        }
      }

      setSuccess(true);
      onFinancialsUpdated();

      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1200);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg max-w-xl w-full p-6 text-white font-mono shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-500 hover:text-white p-1 rounded transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-5 border-b border-zinc-800 pb-3">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-white" />
            <h2 className="text-base font-bold tracking-tight">Record Today&apos;s Financials</h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1 font-sans">
            Company: <span className="font-mono text-white">{company.business_name}</span> • Date:{' '}
            <span className="font-mono text-white">{todayDateStr}</span>
          </p>
        </div>

        {/* Current status chip */}
        <div className="mb-4 p-3 bg-black border border-zinc-800 rounded text-xs flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Calendar className="w-4 h-4 text-zinc-400" />
            <span>Target Requirements:</span>
          </div>
          <div className="flex items-center space-x-3 text-[11px]">
            <span
              className={
                financialStatus?.hasIncome ? 'text-emerald-400' : 'text-amber-400 font-semibold'
              }
            >
              Income: {financialStatus?.hasIncome ? 'Logged' : 'Missing'}
            </span>
            <span>•</span>
            <span
              className={
                financialStatus?.hasExpensesOrProfit
                  ? 'text-emerald-400'
                  : 'text-amber-400 font-semibold'
              }
            >
              Profit/Expenses: {financialStatus?.hasExpensesOrProfit ? 'Logged' : 'Missing'}
            </span>
          </div>
        </div>

        {/* Mode Selector */}
        <div className="flex border border-zinc-800 rounded p-1 bg-black mb-4 text-xs">
          <button
            type="button"
            onClick={() => setActiveMode('both')}
            className={`flex-1 py-1.5 rounded text-center transition-colors ${
              activeMode === 'both' ? 'bg-white text-black font-bold' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Update Income &amp; Expenses (Profit)
          </button>
          <button
            type="button"
            onClick={() => setActiveMode('income')}
            className={`flex-1 py-1.5 rounded text-center transition-colors ${
              activeMode === 'income' ? 'bg-white text-black font-bold' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Income Only
          </button>
          <button
            type="button"
            onClick={() => setActiveMode('expense')}
            className={`flex-1 py-1.5 rounded text-center transition-colors ${
              activeMode === 'expense' ? 'bg-white text-black font-bold' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Expenses Only
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-4 p-2.5 bg-red-950/60 border border-red-800 rounded text-xs text-red-200 flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Success Alert */}
        {success && (
          <div className="mb-4 p-2.5 bg-emerald-950/60 border border-emerald-800 rounded text-xs text-emerald-200 flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Financial details updated! Reminder cleared.</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Section 1: Income */}
          {(activeMode === 'both' || activeMode === 'income') && (
            <div className="p-3.5 bg-black border border-zinc-800 rounded-md space-y-3">
              <div className="flex items-center justify-between text-zinc-400 font-semibold border-b border-zinc-900 pb-1.5">
                <span className="flex items-center space-x-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Today&apos;s Income</span>
                </span>
                <span className="text-[11px] text-zinc-500 font-normal">Currency: {company.currency}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] uppercase text-zinc-500 mb-1">
                    Amount ({company.currency}) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={incomeAmount}
                    onChange={(e) => setIncomeAmount(e.target.value)}
                    placeholder="0.00"
                    required
                    className="w-full bg-zinc-950 border border-zinc-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase text-zinc-500 mb-1">Category *</label>
                  <select
                    value={incomeCategory}
                    onChange={(e) => setIncomeCategory(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded px-2.5 py-1.5 text-white focus:border-white outline-none"
                  >
                    <option value="Services">Services / Retainer</option>
                    <option value="Consulting">Consulting</option>
                    <option value="Product Sales">Product Sales</option>
                    <option value="Software License">Software License</option>
                    <option value="Other">Other Revenue</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase text-zinc-500 mb-1">Description *</label>
                <input
                  type="text"
                  value={incomeDesc}
                  onChange={(e) => setIncomeDesc(e.target.value)}
                  placeholder="e.g. Monthly maintenance contract payment"
                  required
                  className="w-full bg-zinc-950 border border-zinc-700 rounded px-2.5 py-1.5 text-white focus:border-white outline-none"
                />
              </div>
            </div>
          )}

          {/* Section 2: Expense (for Profit computation) */}
          {(activeMode === 'both' || activeMode === 'expense') && (
            <div className="p-3.5 bg-black border border-zinc-800 rounded-md space-y-3">
              <div className="flex items-center justify-between text-zinc-400 font-semibold border-b border-zinc-900 pb-1.5">
                <span className="flex items-center space-x-1.5">
                  <Tag className="w-3.5 h-3.5 text-amber-400" />
                  <span>Today&apos;s Expenses / Operating Costs</span>
                </span>
                <span className="text-[11px] text-zinc-500 font-normal">Currency: {company.currency}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] uppercase text-zinc-500 mb-1">
                    Amount ({company.currency}) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={expenseAmount}
                    onChange={(e) => setExpenseAmount(e.target.value)}
                    placeholder="0.00"
                    required
                    className="w-full bg-zinc-950 border border-zinc-700 rounded px-2.5 py-1.5 text-white font-mono focus:border-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase text-zinc-500 mb-1">Category *</label>
                  <select
                    value={expenseCategory}
                    onChange={(e) => setExpenseCategory(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded px-2.5 py-1.5 text-white focus:border-white outline-none"
                  >
                    <option value="Software">Software &amp; Tools</option>
                    <option value="Salary">Salary &amp; Wages</option>
                    <option value="Rent">Rent &amp; Utilities</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Equipment">Equipment</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase text-zinc-500 mb-1">Description *</label>
                <input
                  type="text"
                  value={expenseDesc}
                  onChange={(e) => setExpenseDesc(e.target.value)}
                  placeholder="e.g. Cloud server invoice settlement"
                  required
                  className="w-full bg-zinc-950 border border-zinc-700 rounded px-2.5 py-1.5 text-white focus:border-white outline-none"
                />
              </div>
            </div>
          )}

          {/* Computed Profit Preview */}
          {activeMode === 'both' && (
            <div className="p-3 bg-zinc-900 border border-zinc-800 rounded flex items-center justify-between text-xs font-mono">
              <span className="text-zinc-400">Calculated Today&apos;s Net Profit:</span>
              <span
                className={`font-bold text-sm ${
                  calculatedProfit >= 0 ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                {company.currency} {calculatedProfit.toLocaleString('en-IN')}
              </span>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-zinc-700 hover:bg-zinc-900 rounded text-zinc-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-white text-black hover:bg-zinc-200 font-bold rounded transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : 'Save & Clear Reminder'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
