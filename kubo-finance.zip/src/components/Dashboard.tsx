import React from 'react';
import {
  AlertCircle,
  TrendingUp,
  DollarSign,
  FileText,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  CheckCircle2,
  BellRing,
  Building,
  ExternalLink,
  Shield,
  Zap,
} from 'lucide-react';
import {
  Business,
  DailyFinancialStatus,
  ExpenseRecord,
  IncomeRecord,
  InvoiceRecord,
  PaymentRecord,
} from '../types';

interface DashboardProps {
  company: Business;
  financialStatus: DailyFinancialStatus | null;
  incomes: IncomeRecord[];
  expenses: ExpenseRecord[];
  invoices: InvoiceRecord[];
  payments: PaymentRecord[];
  onOpenFinancialUpdate: () => void;
  onNavigateTab: (tab: string) => void;
  onTriggerDailyCheck: () => void;
  isTriggeringCheck: boolean;
}

export const Dashboard: React.FC<DashboardProps> = ({
  company,
  financialStatus,
  incomes,
  expenses,
  invoices,
  payments,
  onOpenFinancialUpdate,
  onNavigateTab,
  onTriggerDailyCheck,
  isTriggeringCheck,
}) => {
  const currency = company.currency || 'INR';

  // Calculate Aggregates
  const totalIncome = incomes.reduce((acc, curr) => acc + Number(curr.amount), 0);
  const totalExpenses = expenses.reduce((acc, curr) => acc + Number(curr.amount), 0);
  const netProfit = totalIncome - totalExpenses;

  const unpaidInvoices = invoices.filter(
    (inv) => inv.status === 'Sent' || inv.status === 'Overdue' || inv.status === 'Partially Paid',
  );
  const unpaidTotal = unpaidInvoices.reduce((acc, curr) => acc + Number(curr.total), 0);

  const todayDateStr = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-6 font-mono text-white">
      {/* ---------------------------------------------------------------- */}
      {/* 1. MANDATED DAILY FINANCIAL REMINDER CARD (ONLY WHEN MISSING)     */}
      {/* ---------------------------------------------------------------- */}
      {financialStatus?.needsReminder ? (
        <div className="border-2 border-white bg-zinc-950 p-5 sm:p-6 rounded-lg shadow-2xl relative overflow-hidden transition-all animate-in fade-in duration-300">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center space-x-2.5">
                <span className="inline-flex p-1.5 bg-white text-black rounded-md">
                  <BellRing className="w-4 h-4" />
                </span>
                <h2 className="text-base sm:text-lg font-bold tracking-tight text-white uppercase">
                  Daily Financial Reminder
                </h2>
                <span className="bg-amber-950/80 border border-amber-700 text-amber-300 text-[10px] px-2 py-0.5 rounded uppercase font-semibold">
                  Action Required
                </span>
              </div>

              <p className="text-sm text-zinc-300 font-sans leading-relaxed pt-1">
                Today&apos;s income and profit details have not been updated.
              </p>

              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-400 font-sans pt-1">
                <span>
                  Company Target:{' '}
                  <strong className="text-white font-mono">{company.business_name}</strong>
                </span>
                <span>•</span>
                <span>
                  Date: <strong className="text-white font-mono">{todayDateStr}</strong>
                </span>
                <span>•</span>
                <span className="text-zinc-400">
                  Reminder dispatched to:{' '}
                  <strong className="text-zinc-200 font-mono">
                    {company.contact?.contactPersonName || 'Saved Company Contact'}
                  </strong>
                </span>
              </div>
            </div>

            {/* MANDATED "UPDATE NOW" BUTTON */}
            <div className="flex items-center space-x-3 shrink-0">
              <button
                onClick={onOpenFinancialUpdate}
                className="px-6 py-2.5 bg-white text-black hover:bg-zinc-200 font-bold text-xs uppercase tracking-wider rounded transition-transform active:scale-95 shadow-md flex items-center space-x-2"
              >
                <span>Update Now</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Status Card when Financials ARE Updated */
        <div className="border border-emerald-900/60 bg-emerald-950/20 p-4 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <span className="text-emerald-300 font-semibold">
                Daily Financial Update Complete:
              </span>{' '}
              <span className="text-zinc-300 font-sans">
                Income and profit details for {todayDateStr} are already logged. No reminder needed.
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-3 text-[11px] text-zinc-400">
            <span>
              Today&apos;s Income: <strong className="text-white font-mono">{currency} {financialStatus?.totalIncomeToday.toLocaleString('en-IN')}</strong>
            </span>
            <span>•</span>
            <span>
              Today&apos;s Profit: <strong className="text-emerald-400 font-mono">{currency} {financialStatus?.calculatedProfitToday.toLocaleString('en-IN')}</strong>
            </span>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------------- */}
      {/* 2. KUBO FINANCIAL KPI OVERVIEW CARDS                            */}
      {/* ---------------------------------------------------------------- */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Income */}
        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-lg">
          <div className="flex items-center justify-between text-zinc-500 text-xs mb-2">
            <span className="uppercase tracking-wider">Total Revenue</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            {currency} {totalIncome.toLocaleString('en-IN')}
          </div>
          <div className="flex items-center justify-between mt-2 text-[11px] text-zinc-500 font-sans">
            <span>{incomes.length} recorded payments</span>
            <button
              onClick={() => onNavigateTab('incomes')}
              className="text-zinc-400 hover:text-white underline font-mono"
            >
              View
            </button>
          </div>
        </div>

        {/* Total Expenses */}
        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-lg">
          <div className="flex items-center justify-between text-zinc-500 text-xs mb-2">
            <span className="uppercase tracking-wider">Total Expenses</span>
            <ArrowDownRight className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            {currency} {totalExpenses.toLocaleString('en-IN')}
          </div>
          <div className="flex items-center justify-between mt-2 text-[11px] text-zinc-500 font-sans">
            <span>{expenses.length} expense items</span>
            <button
              onClick={() => onNavigateTab('expenses')}
              className="text-zinc-400 hover:text-white underline font-mono"
            >
              View
            </button>
          </div>
        </div>

        {/* Net Profit */}
        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-lg">
          <div className="flex items-center justify-between text-zinc-500 text-xs mb-2">
            <span className="uppercase tracking-wider">Net Profit</span>
            <TrendingUp className="w-4 h-4 text-white" />
          </div>
          <div
            className={`text-xl sm:text-2xl font-bold tracking-tight ${
              netProfit >= 0 ? 'text-white' : 'text-red-400'
            }`}
          >
            {currency} {netProfit.toLocaleString('en-IN')}
          </div>
          <div className="flex items-center justify-between mt-2 text-[11px] text-zinc-500 font-sans">
            <span>
              Margin: {totalIncome > 0 ? Math.round((netProfit / totalIncome) * 100) : 0}%
            </span>
            <span className="text-zinc-400 font-mono">
              {netProfit >= 0 ? 'Profitable' : 'Deficit'}
            </span>
          </div>
        </div>

        {/* Unpaid Invoices */}
        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-lg">
          <div className="flex items-center justify-between text-zinc-500 text-xs mb-2">
            <span className="uppercase tracking-wider">Unpaid Invoices</span>
            <FileText className="w-4 h-4 text-zinc-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            {currency} {unpaidTotal.toLocaleString('en-IN')}
          </div>
          <div className="flex items-center justify-between mt-2 text-[11px] text-zinc-500 font-sans">
            <span>{unpaidInvoices.length} pending receivables</span>
            <button
              onClick={() => onNavigateTab('invoices')}
              className="text-zinc-400 hover:text-white underline font-mono"
            >
              Invoices
            </button>
          </div>
        </div>
      </div>

      {/* ---------------------------------------------------------------- */}
      {/* 3. QUICK VERIFICATION & TEST CONSOLE                             */}
      {/* ---------------------------------------------------------------- */}
      <div className="bg-black border border-zinc-800 rounded-lg p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-800/80">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-white" />
            <span className="text-xs font-bold uppercase tracking-wider text-white">
              Automated Daily Financial Reminder Engine
            </span>
          </div>
          <button
            onClick={onTriggerDailyCheck}
            disabled={isTriggeringCheck}
            className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-white rounded transition-colors self-start sm:self-auto disabled:opacity-50"
          >
            <BellRing className={`w-3.5 h-3.5 ${isTriggeringCheck ? 'animate-bounce' : ''}`} />
            <span>{isTriggeringCheck ? 'Running Daily Check...' : 'Trigger Daily Check Now'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 text-xs text-zinc-400 font-sans">
          <div className="border border-zinc-900 bg-zinc-950 p-3 rounded">
            <span className="font-mono text-[11px] text-zinc-500 uppercase block mb-1">
              Active Company
            </span>
            <span className="font-mono font-bold text-white text-sm block">
              {company.business_name}
            </span>
            <span className="text-[11px] text-zinc-500">
              Assigned Contact: {company.contact?.contactPersonName}
            </span>
          </div>

          <div className="border border-zinc-900 bg-zinc-950 p-3 rounded">
            <span className="font-mono text-[11px] text-zinc-500 uppercase block mb-1">
              Today&apos;s Financial Status
            </span>
            <span
              className={`font-mono font-bold text-sm block ${
                financialStatus?.isFullyUpdated ? 'text-emerald-400' : 'text-amber-400'
              }`}
            >
              {financialStatus?.isFullyUpdated ? 'Updated & Accurate' : 'Pending (Needs Reminder)'}
            </span>
            <span className="text-[11px] text-zinc-500">
              Income: {financialStatus?.hasIncome ? 'Yes' : 'No'} | Profit/Expense:{' '}
              {financialStatus?.hasExpensesOrProfit ? 'Yes' : 'No'}
            </span>
          </div>

          <div className="border border-zinc-900 bg-zinc-950 p-3 rounded">
            <span className="font-mono text-[11px] text-zinc-500 uppercase block mb-1">
              Duplicate Protection
            </span>
            <span className="font-mono font-bold text-white text-sm block">
              {financialStatus?.reminderSentToday ? 'Reminder Dispatched Today' : 'Ready for Check'}
            </span>
            <span className="text-[11px] text-zinc-500">
              Policy: Max 1 reminder per company / day
            </span>
          </div>
        </div>
      </div>

      {/* ---------------------------------------------------------------- */}
      {/* 4. RECENT TRANSACTIONS & INVOICES PREVIEW                         */}
      {/* ---------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Invoices */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800 text-xs">
            <div className="flex items-center space-x-2">
              <FileText className="w-4 h-4 text-white" />
              <span className="font-bold uppercase tracking-wider text-white">Recent Invoices</span>
            </div>
            <button
              onClick={() => onNavigateTab('invoices')}
              className="text-zinc-400 hover:text-white text-[11px] underline"
            >
              All Invoices ({invoices.length})
            </button>
          </div>

          <div className="mt-3 divide-y divide-zinc-900">
            {invoices.slice(0, 4).map((inv) => (
              <div key={inv.id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-white">{inv.invoice_number}</div>
                  <div className="text-[11px] text-zinc-500 font-sans">{inv.customer_name}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">
                    {currency} {Number(inv.total).toLocaleString('en-IN')}
                  </div>
                  <span
                    className={`inline-block text-[10px] px-1.5 py-0.5 rounded font-sans uppercase ${
                      inv.status === 'Paid'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-900'
                        : inv.status === 'Sent'
                        ? 'bg-blue-950 text-blue-400 border border-blue-900'
                        : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
                    }`}
                  >
                    {inv.status}
                  </span>
                </div>
              </div>
            ))}

            {invoices.length === 0 && (
              <div className="py-6 text-center text-xs text-zinc-500">No invoices recorded yet.</div>
            )}
          </div>
        </div>

        {/* Recent Incomes & Expenses */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800 text-xs">
            <div className="flex items-center space-x-2">
              <DollarSign className="w-4 h-4 text-white" />
              <span className="font-bold uppercase tracking-wider text-white">
                Recent Financial Entries
              </span>
            </div>
            <button
              onClick={onOpenFinancialUpdate}
              className="text-zinc-400 hover:text-white text-[11px] underline"
            >
              + Record Financials
            </button>
          </div>

          <div className="mt-3 divide-y divide-zinc-900">
            {incomes.slice(0, 3).map((inc) => (
              <div key={inc.id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-emerald-400 flex items-center space-x-1">
                    <span>+ Income</span>
                    <span className="text-zinc-500 text-[10px]">({inc.category})</span>
                  </div>
                  <div className="text-[11px] text-zinc-400 truncate max-w-[200px] font-sans">
                    {inc.description}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">
                    {currency} {Number(inc.amount).toLocaleString('en-IN')}
                  </div>
                  <span className="text-[10px] text-zinc-500">{inc.income_date}</span>
                </div>
              </div>
            ))}

            {expenses.slice(0, 3).map((exp) => (
              <div key={exp.id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-amber-400 flex items-center space-x-1">
                    <span>- Expense</span>
                    <span className="text-zinc-500 text-[10px]">({exp.category})</span>
                  </div>
                  <div className="text-[11px] text-zinc-400 truncate max-w-[200px] font-sans">
                    {exp.description}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">
                    {currency} {Number(exp.amount).toLocaleString('en-IN')}
                  </div>
                  <span className="text-[10px] text-zinc-500">{exp.expense_date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
