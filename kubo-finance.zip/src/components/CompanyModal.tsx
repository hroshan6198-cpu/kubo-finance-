import React, { useState, useEffect } from 'react';
import { X, Building2, Globe, Mail, Phone, User, FileText } from 'lucide-react';
import { Business } from '../types';

interface CompanyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: {
    business_name: string;
    business_type: string;
    currency: string;
    description: string;
    website: string;
    contactPersonName?: string;
    phoneNumber?: string;
    emailAddress?: string;
  }) => Promise<void>;
  companyToEdit?: Business | null;
}

export const CompanyModal: React.FC<CompanyModalProps> = ({
  isOpen,
  onClose,
  onSave,
  companyToEdit,
}) => {
  const [businessName, setBusinessName] = useState('');
  const [businessType, setBusinessType] = useState('Software & Cloud Services');
  const [currency, setCurrency] = useState('INR');
  const [description, setDescription] = useState('');
  const [website, setWebsite] = useState('');
  const [contactPersonName, setContactPersonName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [emailAddress, setEmailAddress] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (companyToEdit) {
      setBusinessName(companyToEdit.business_name || '');
      setBusinessType(companyToEdit.business_type || 'General Business');
      setCurrency(companyToEdit.currency || 'INR');
      setDescription(companyToEdit.description || '');
      setWebsite(companyToEdit.website || '');
      setContactPersonName(companyToEdit.contact?.contactPersonName || '');
      setPhoneNumber(companyToEdit.contact?.phoneNumber || '');
      setEmailAddress(companyToEdit.contact?.emailAddress || '');
    } else {
      setBusinessName('');
      setBusinessType('Software & Cloud Services');
      setCurrency('INR');
      setDescription('');
      setWebsite('');
      setContactPersonName('');
      setPhoneNumber('');
      setEmailAddress('');
    }
    setFormError(null);
  }, [companyToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessName.trim()) {
      setFormError('Company Name is required.');
      return;
    }

    if (phoneNumber && phoneNumber.replace(/\D/g, '').length < 8) {
      setFormError('Phone number must have at least 8 digits.');
      return;
    }

    if (emailAddress && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailAddress)) {
      setFormError('Please enter a valid email address.');
      return;
    }

    setIsSubmitting(true);
    setFormError(null);

    try {
      await onSave({
        business_name: businessName.trim(),
        business_type: businessType.trim(),
        currency,
        description: description.trim(),
        website: website.trim(),
        contactPersonName: contactPersonName.trim(),
        phoneNumber: phoneNumber.trim(),
        emailAddress: emailAddress.trim().toLowerCase(),
      });
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setFormError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-zinc-950 border border-zinc-700 rounded-lg shadow-2xl p-6 font-mono text-zinc-200">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center space-x-2.5">
            <Building2 className="w-5 h-5 text-zinc-300" />
            <h3 className="font-bold text-sm tracking-wide uppercase text-white">
              {companyToEdit ? 'Edit Company Entity' : 'Add New Company'}
            </h3>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="text-zinc-500 hover:text-white p-1 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {formError && (
          <div className="mt-4 p-3 bg-rose-950/50 border border-rose-800 text-rose-300 text-xs rounded">
            {formError}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Company Name *
            </label>
            <input
              type="text"
              required
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="e.g. Acme Corp Technologies"
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
                Company Type / Industry
              </label>
              <input
                type="text"
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                placeholder="e.g. Software, Consulting, Design"
                className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:border-white transition-colors"
              />
            </div>
            <div>
              <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
                Accounting Currency
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:border-white transition-colors"
              >
                <option value="INR">INR (₹)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="SGD">SGD (S$)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1 flex items-center space-x-1.5">
              <Globe className="w-3.5 h-3.5 text-zinc-500" />
              <span>Website</span>
            </label>
            <input
              type="url"
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
              placeholder="https://example.com"
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1 flex items-center space-x-1.5">
              <FileText className="w-3.5 h-3.5 text-zinc-500" />
              <span>Company Description</span>
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of enterprise operations and business domain..."
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div className="pt-2 border-t border-zinc-800">
            <span className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider block mb-2">
              Primary Company Contact
            </span>
            <div className="space-y-3">
              <div>
                <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1 flex items-center space-x-1.5">
                  <User className="w-3.5 h-3.5 text-zinc-500" />
                  <span>Contact Person Name</span>
                </label>
                <input
                  type="text"
                  value={contactPersonName}
                  onChange={(e) => setContactPersonName(e.target.value)}
                  placeholder="e.g. Rajesh Sharma"
                  className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:border-white transition-colors"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1 flex items-center space-x-1.5">
                    <Phone className="w-3.5 h-3.5 text-zinc-500" />
                    <span>Phone Number</span>
                  </label>
                  <input
                    type="text"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="+91 98201 54321"
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:border-white transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1 flex items-center space-x-1.5">
                    <Mail className="w-3.5 h-3.5 text-zinc-500" />
                    <span>Email Address</span>
                  </label>
                  <input
                    type="email"
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    placeholder="contact@company.com"
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:border-white transition-colors"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 rounded font-mono transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-white hover:bg-zinc-200 text-black font-semibold rounded font-mono transition-colors flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <span className="w-3 h-3 border-2 border-black/40 border-t-black rounded-full animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <span>{companyToEdit ? 'Save Changes' : 'Create Company'}</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
