import React, { useState, useEffect } from 'react';
import { X, TrendingUp } from 'lucide-react';
import { IncomeRecord } from '../types';

interface EditIncomeModalProps {
  isOpen: boolean;
  income: IncomeRecord | null;
  currency: string;
  onClose: () => void;
  onSave: (id: string, data: { amount: number; description: string; category: string; income_date: string }) => Promise<void>;
}

export const EditIncomeModal: React.FC<EditIncomeModalProps> = ({
  isOpen,
  income,
  currency,
  onClose,
  onSave,
}) => {
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Consulting');
  const [date, setDate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (income) {
      setAmount(String(income.amount));
      setDescription(income.description || '');
      setCategory(income.category || 'Consulting');
      setDate(income.income_date ? income.income_date.split('T')[0] : '');
    }
    setError(null);
  }, [income, isOpen]);

  if (!isOpen || !income) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) {
      setError('Amount must be greater than 0.');
      return;
    }
    if (!description.trim()) {
      setError('Description is required.');
      return;
    }
    if (!date) {
      setError('Date is required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await onSave(income.id, {
        amount: num,
        description: description.trim(),
        category,
        income_date: date,
      });
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-zinc-950 border border-zinc-700 rounded-lg shadow-2xl p-6 font-mono text-zinc-200">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center space-x-2.5">
            <TrendingUp className="w-5 h-5 text-zinc-300" />
            <h3 className="font-bold text-sm tracking-wide uppercase text-white">Edit Income Entry</h3>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="text-zinc-500 hover:text-white p-1 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-2.5 bg-rose-950/50 border border-rose-800 text-rose-300 text-xs rounded">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Amount ({currency}) *
            </label>
            <input
              type="number"
              step="any"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Category *
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            >
              <option value="Consulting">Consulting</option>
              <option value="Services">Services / Retainer</option>
              <option value="Product Sales">Product Sales</option>
              <option value="Software License">Software License</option>
              <option value="Design Retainer">Design Retainer</option>
              <option value="General Revenue">General Revenue</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Income Date *
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div>
            <label className="block text-zinc-400 uppercase text-[10px] tracking-wider mb-1">
              Description *
            </label>
            <input
              type="text"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-white transition-colors"
            />
          </div>

          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 rounded font-mono transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-white hover:bg-zinc-200 text-black font-semibold rounded font-mono transition-colors flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <span className="w-3 h-3 border-2 border-black/40 border-t-black rounded-full animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <span>Save Changes</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
