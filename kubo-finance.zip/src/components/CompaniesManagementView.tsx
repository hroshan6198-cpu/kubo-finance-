import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Edit2,
  Trash2,
  Globe,
  Mail,
  Phone,
  User,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Search,
  ExternalLink,
  Shield,
  Layers,
} from 'lucide-react';
import { Business, DailyFinancialStatus } from '../types';
import { ConfirmDeleteModal } from './ConfirmDeleteModal';
import { CompanyModal } from './CompanyModal';

interface CompaniesManagementViewProps {
  companies: Business[];
  activeCompany: Business;
  onSelectCompany: (company: Business) => void;
  onCompanyCreated: (newCompany: Business) => void;
  onCompanyUpdated: (updatedCompany: Business) => void;
  onCompanyDeleted: (deletedId: string) => void;
  onFinancialDataCleared: (companyId: string) => void;
  showToast: (type: 'success' | 'error' | 'info', message: string, description?: string) => void;
}

export const CompaniesManagementView: React.FC<CompaniesManagementViewProps> = ({
  companies,
  activeCompany,
  onSelectCompany,
  onCompanyCreated,
  onCompanyUpdated,
  onCompanyDeleted,
  onFinancialDataCleared,
  showToast,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Business | null>(null);

  // Deletion modals
  const [deletingCompany, setDeletingCompany] = useState<Business | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Clear financial data modal
  const [clearingFinancialCompany, setClearingFinancialCompany] = useState<Business | null>(null);
  const [isClearingFinancial, setIsClearingFinancial] = useState(false);

  const filteredCompanies = companies.filter(
    (c) =>
      c.business_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.business_type?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.contact?.contactPersonName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.contact?.emailAddress?.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const handleSaveCompany = async (data: {
    business_name: string;
    business_type: string;
    currency: string;
    description: string;
    website: string;
    contactPersonName?: string;
    phoneNumber?: string;
    emailAddress?: string;
  }) => {
    if (editingCompany) {
      // Update company
      const res = await fetch(`/api/companies/${editingCompany.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          business_name: data.business_name,
          business_type: data.business_type,
          currency: data.currency,
          description: data.description,
          website: data.website,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to update company');
      }

      const updated = await res.json();

      // If contact info also changed, update contact
      if (data.contactPersonName && data.phoneNumber && data.emailAddress) {
        const contactRes = await fetch(`/api/companies/${editingCompany.id}/contact`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            companyName: data.business_name,
            contactPersonName: data.contactPersonName,
            phoneNumber: data.phoneNumber,
            emailAddress: data.emailAddress,
          }),
        });
        if (contactRes.ok) {
          const contactData = await contactRes.json();
          onCompanyUpdated(contactData.company);
          showToast('success', 'Company and contact updated successfully.');
          return;
        }
      }

      onCompanyUpdated(updated);
      showToast('success', 'Company profile updated successfully.');
    } else {
      // Create company
      const res = await fetch('/api/companies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to create company');
      }

      const created = await res.json();
      onCompanyCreated(created);
      showToast('success', `Created company "${created.business_name}".`);
    }
  };

  const handleConfirmDeleteCompany = async () => {
    if (!deletingCompany) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/companies/${deletingCompany.id}`, {
        method: 'DELETE',
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to delete company');
      }
      onCompanyDeleted(deletingCompany.id);
      showToast('info', `Deleted company "${deletingCompany.business_name}".`);
      setDeletingCompany(null);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      showToast('error', msg);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleConfirmClearFinancialData = async () => {
    if (!clearingFinancialCompany) return;
    setIsClearingFinancial(true);
    try {
      const res = await fetch(`/api/companies/${clearingFinancialCompany.id}/clear-financial-data`, {
        method: 'POST',
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to reset financial records');
      }
      onFinancialDataCleared(clearingFinancialCompany.id);
      showToast(
        'info',
        `Financial data cleared for "${clearingFinancialCompany.business_name}".`,
        'All other companies and contacts remain completely intact.',
      );
      setClearingFinancialCompany(null);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      showToast('error', msg);
    } finally {
      setIsClearingFinancial(false);
    }
  };

  return (
    <div className="space-y-6 font-mono text-white">
      {/* Header Banner */}
      <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-white" />
            <h2 className="text-base font-bold tracking-tight">
              Company &amp; Contact Management
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1 font-sans">
            Maintain independent multi-tenant enterprise profiles, websites, and authorized contact persons.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingCompany(null);
            setIsAddModalOpen(true);
          }}
          className="inline-flex items-center space-x-1.5 px-4 py-2 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Company</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-zinc-950 border border-zinc-800 p-3 rounded-lg text-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search companies, contacts, emails..."
            className="w-full bg-black border border-zinc-800 rounded pl-9 pr-3 py-1.5 text-white font-mono focus:border-white outline-none"
          />
        </div>
        <div className="text-[11px] text-zinc-400 w-full sm:w-auto text-right">
          Showing <span className="text-white font-bold">{filteredCompanies.length}</span> of{' '}
          <span className="text-white font-bold">{companies.length}</span> companies
        </div>
      </div>

      {/* Company Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredCompanies.map((c) => {
          const isActive = c.id === activeCompany.id;
          const hasContact = Boolean(c.contact?.contactPersonName && c.contact?.emailAddress);

          return (
            <div
              key={c.id}
              className={`bg-zinc-950 border rounded-lg p-5 flex flex-col justify-between transition-all ${
                isActive
                  ? 'border-white ring-1 ring-white/20'
                  : 'border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <div>
                {/* Card Top Row */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-sm text-white">{c.business_name}</span>
                      {isActive && (
                        <span className="text-[10px] bg-white text-black px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                          Active
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-zinc-400 mt-0.5 font-sans">
                      {c.business_type || 'General Entity'} • Currency: {c.currency || 'INR'}
                    </div>
                  </div>

                  <div className="flex items-center space-x-1.5">
                    <button
                      onClick={() => {
                        setEditingCompany(c);
                        setIsAddModalOpen(true);
                      }}
                      title="Edit Company"
                      className="p-1.5 text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800 rounded hover:border-zinc-700 transition-colors"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeletingCompany(c)}
                      title="Delete Company"
                      className="p-1.5 text-zinc-400 hover:text-rose-400 bg-zinc-900 border border-zinc-800 rounded hover:border-zinc-700 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Description & Website */}
                {c.description && (
                  <p className="text-xs text-zinc-300 mt-3 font-sans leading-relaxed line-clamp-2">
                    {c.description}
                  </p>
                )}

                {c.website && (
                  <div className="mt-2.5 flex items-center space-x-1.5 text-xs text-zinc-400 hover:text-white">
                    <Globe className="w-3.5 h-3.5 text-zinc-500" />
                    <a
                      href={c.website.startsWith('http') ? c.website : `https://${c.website}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="underline decoration-zinc-700 hover:decoration-white truncate"
                    >
                      {c.website.replace(/^https?:\/\//, '')}
                    </a>
                  </div>
                )}

                {/* Contact Information Sub-Panel */}
                <div className="mt-4 pt-3 border-t border-zinc-900 bg-black/40 -mx-2 px-3 py-2.5 rounded">
                  <div className="flex items-center justify-between text-[10px] text-zinc-400 uppercase tracking-wider mb-2">
                    <span className="font-bold">Authorized Company Contact</span>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[9px] ${
                        hasContact
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {hasContact ? 'Verified' : 'Incomplete'}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs font-mono">
                    <div className="flex items-center space-x-2 text-zinc-200">
                      <User className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                      <span className="truncate">{c.contact?.contactPersonName || 'Not Set'}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-zinc-300 text-[11px]">
                      <Phone className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                      <span className="truncate">{c.contact?.phoneNumber || 'Not Set'}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-zinc-300 text-[11px]">
                      <Mail className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                      <span className="truncate">{c.contact?.emailAddress || 'Not Set'}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="mt-5 pt-3 border-t border-zinc-900 flex items-center justify-between gap-2">
                <button
                  onClick={() => setClearingFinancialCompany(c)}
                  className="text-[11px] text-zinc-500 hover:text-rose-400 transition-colors flex items-center space-x-1"
                  title="Clear financial data for this company"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Data</span>
                </button>

                {!isActive ? (
                  <button
                    onClick={() => onSelectCompany(c)}
                    className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-200 rounded font-bold transition-colors"
                  >
                    Select Active Company
                  </button>
                ) : (
                  <span className="text-[11px] text-zinc-400 font-sans">
                    Currently Selected Workspace
                  </span>
                )}
              </div>
            </div>
          );
        })}

        {filteredCompanies.length === 0 && (
          <div className="col-span-full p-8 text-center bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-500 text-xs">
            No companies found matching &ldquo;{searchTerm}&rdquo;.
          </div>
        )}
      </div>

      {/* Add / Edit Company Modal */}
      <CompanyModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingCompany(null);
        }}
        onSave={handleSaveCompany}
        companyToEdit={editingCompany}
      />

      {/* Confirm Delete Company Modal */}
      <ConfirmDeleteModal
        isOpen={Boolean(deletingCompany)}
        onClose={() => setDeletingCompany(null)}
        onConfirm={handleConfirmDeleteCompany}
        title="Delete this record?"
        message={`Are you sure you want to delete company "${deletingCompany?.business_name}"? All associated invoices, incomes, expenses, and contacts scoped strictly to this company will be removed. This action cannot be undone.`}
        confirmLabel="Delete"
        cancelLabel="Cancel"
        isDeleting={isDeleting}
      />

      {/* Confirm Clear Financial Records Modal */}
      <ConfirmDeleteModal
        isOpen={Boolean(clearingFinancialCompany)}
        onClose={() => setClearingFinancialCompany(null)}
        onConfirm={handleConfirmClearFinancialData}
        title="Delete this record?"
        message={`Are you sure you want to delete your financial records? This action cannot be undone. All income, expense, invoice, and payment entries for "${clearingFinancialCompany?.business_name}" will be reset, while company contact and profile details remain preserved.`}
        confirmLabel="Clear Financial Data"
        cancelLabel="Cancel"
        isDeleting={isClearingFinancial}
      />
    </div>
  );
};
