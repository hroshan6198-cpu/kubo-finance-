import React, { useState, useEffect } from 'react';
import {
  User,
  Phone,
  Mail,
  Building,
  Edit3,
  Check,
  X,
  AlertCircle,
  Clock,
  Shield,
  Send,
} from 'lucide-react';
import { Business, CompanyContact } from '../types';

interface CompanyContactSectionProps {
  company: Business;
  onContactUpdated: (updatedCompany: Business) => void;
  onRequestTestReminder?: () => void;
}

export const CompanyContactSection: React.FC<CompanyContactSectionProps> = ({
  company,
  onContactUpdated,
  onRequestTestReminder,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [companyName, setCompanyName] = useState(company.business_name || '');
  const [contactPersonName, setContactPersonName] = useState(
    company.contact?.contactPersonName || '',
  );
  const [phoneNumber, setPhoneNumber] = useState(company.contact?.phoneNumber || '');
  const [emailAddress, setEmailAddress] = useState(company.contact?.emailAddress || '');

  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync state whenever company changes (e.g. switching between Company A and Company B)
  useEffect(() => {
    setCompanyName(company.business_name || company.contact?.companyName || '');
    setContactPersonName(company.contact?.contactPersonName || '');
    setPhoneNumber(company.contact?.phoneNumber || '');
    setEmailAddress(company.contact?.emailAddress || '');
    setIsEditing(false);
    setError(null);
    setSuccessMessage(null);
  }, [company.id, company.updated_at, company.business_name, company.contact]);

  // Client-side phone and email validation
  const validateInputs = (): string | null => {
    if (!companyName.trim()) {
      return 'Company Name is required.';
    }
    if (!contactPersonName.trim()) {
      return 'Contact Person Name is required.';
    }

    const cleanPhone = phoneNumber.replace(/[\s\-().]/g, '');
    const phoneRegex = /^\+?[0-9]{7,15}$/;
    if (!phoneRegex.test(cleanPhone)) {
      return 'Invalid Phone Number format. Must be 7-15 digits (e.g., +91 98201 54321).';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailAddress.trim())) {
      return 'Invalid Email Address format (e.g., contact@company.com).';
    }

    return null;
  };

  const handleSaveContact = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    const validationError = validateInputs();
    if (validationError) {
      setError(validationError);
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch(`/api/companies/${company.id}/contact`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          companyName: companyName.trim(),
          contactPersonName: contactPersonName.trim(),
          phoneNumber: phoneNumber.trim(),
          emailAddress: emailAddress.trim(),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to update company contact');
      }

      onContactUpdated(data.company);
      setIsEditing(false);
      setSuccessMessage('Company contact information successfully updated.');
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const contact = company.contact;
  const isConfigured = Boolean(contact?.emailAddress && contact?.phoneNumber);

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5 sm:p-6 text-white font-mono">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-zinc-800 pb-4 mb-5 gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <Building className="w-5 h-5 text-white" />
            <h2 className="text-base font-bold tracking-tight">Company Contact Management</h2>
            <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
              ID: {company.id}
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1 font-sans">
            Recipients for automated daily financial reminders and corporate communication.
          </p>
        </div>

        {!isEditing && (
          <button
            onClick={() => {
              setIsEditing(true);
              setError(null);
            }}
            className="self-start sm:self-auto inline-flex items-center space-x-1.5 px-3 py-1.5 bg-white text-black hover:bg-zinc-200 text-xs font-semibold rounded transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Edit Contact</span>
          </button>
        )}
      </div>

      {/* Feedback Alerts */}
      {error && (
        <div className="mb-4 p-3 bg-red-950/50 border border-red-800 rounded text-xs text-red-200 flex items-start space-x-2">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {successMessage && (
        <div className="mb-4 p-3 bg-emerald-950/50 border border-emerald-800 rounded text-xs text-emerald-200 flex items-start space-x-2">
          <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Content */}
      {isEditing ? (
        <form onSubmit={handleSaveContact} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Company Name */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-zinc-400 mb-1">
                Company Name <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <Building className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g. Acme Corporation"
                  className="w-full bg-black border border-zinc-700 rounded px-3 py-2 pl-9 text-xs text-white focus:outline-none focus:border-white transition-colors"
                  required
                />
              </div>
            </div>

            {/* Contact Person Name */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-zinc-400 mb-1">
                Contact Person Name <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={contactPersonName}
                  onChange={(e) => setContactPersonName(e.target.value)}
                  placeholder="e.g. John Doe / CFO"
                  className="w-full bg-black border border-zinc-700 rounded px-3 py-2 pl-9 text-xs text-white focus:outline-none focus:border-white transition-colors"
                  required
                />
              </div>
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-zinc-400 mb-1">
                Phone Number <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="e.g. +91 98201 54321"
                  className="w-full bg-black border border-zinc-700 rounded px-3 py-2 pl-9 text-xs text-white focus:outline-none focus:border-white transition-colors"
                  required
                />
              </div>
              <p className="text-[11px] text-zinc-500 mt-1">
                Used for SMS/WhatsApp daily financial notifications.
              </p>
            </div>

            {/* Email Address */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-zinc-400 mb-1">
                Email Address <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
                <input
                  type="email"
                  value={emailAddress}
                  onChange={(e) => setEmailAddress(e.target.value)}
                  placeholder="e.g. finance@acme.com"
                  className="w-full bg-black border border-zinc-700 rounded px-3 py-2 pl-9 text-xs text-white focus:outline-none focus:border-white transition-colors"
                  required
                />
              </div>
              <p className="text-[11px] text-zinc-500 mt-1">
                Primary corporate email for reminder dispatch and invoices.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-zinc-800">
            <button
              type="button"
              onClick={() => {
                setIsEditing(false);
                setError(null);
              }}
              disabled={isSubmitting}
              className="px-4 py-2 border border-zinc-700 hover:bg-zinc-900 text-xs text-zinc-300 rounded transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center space-x-2 px-4 py-2 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded transition-colors disabled:opacity-50"
            >
              {isSubmitting ? (
                <span>Saving...</span>
              ) : (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Update Contact</span>
                </>
              )}
            </button>
          </div>
        </form>
      ) : (
        <div className="space-y-6">
          {/* 4 Saved Contact Data Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* 1. Company Name */}
            <div className="bg-black border border-zinc-800/80 p-3.5 rounded-md">
              <div className="flex items-center space-x-2 text-zinc-500 text-[11px] uppercase tracking-wider mb-1">
                <Building className="w-3.5 h-3.5" />
                <span>Company Name</span>
              </div>
              <p className="text-sm font-semibold text-white truncate">
                {company.business_name || contact?.companyName || 'Not Set'}
              </p>
              <span className="text-[10px] text-zinc-500 font-sans block mt-1">
                Entity ID: {company.id}
              </span>
            </div>

            {/* 2. Contact Person */}
            <div className="bg-black border border-zinc-800/80 p-3.5 rounded-md">
              <div className="flex items-center space-x-2 text-zinc-500 text-[11px] uppercase tracking-wider mb-1">
                <User className="w-3.5 h-3.5" />
                <span>Contact Person</span>
              </div>
              <p className="text-sm font-semibold text-white truncate">
                {contact?.contactPersonName || 'Not configured'}
              </p>
              <span className="text-[10px] text-zinc-500 font-sans block mt-1">Authorized Contact</span>
            </div>

            {/* 3. Phone Number */}
            <div className="bg-black border border-zinc-800/80 p-3.5 rounded-md">
              <div className="flex items-center space-x-2 text-zinc-500 text-[11px] uppercase tracking-wider mb-1">
                <Phone className="w-3.5 h-3.5" />
                <span>Phone Number</span>
              </div>
              <p className="text-sm font-semibold text-white truncate">
                {contact?.phoneNumber || 'Not configured'}
              </p>
              <span className="text-[10px] text-zinc-500 font-sans block mt-1">
                {contact?.phoneNumber ? 'Verified for SMS / WhatsApp' : 'Pending'}
              </span>
            </div>

            {/* 4. Email Address */}
            <div className="bg-black border border-zinc-800/80 p-3.5 rounded-md">
              <div className="flex items-center space-x-2 text-zinc-500 text-[11px] uppercase tracking-wider mb-1">
                <Mail className="w-3.5 h-3.5" />
                <span>Email Address</span>
              </div>
              <p className="text-sm font-semibold text-white truncate">
                {contact?.emailAddress || 'Not configured'}
              </p>
              <span className="text-[10px] text-zinc-500 font-sans block mt-1">
                {contact?.emailAddress ? 'Verified for E-delivery' : 'Pending'}
              </span>
            </div>
          </div>

          {/* Status & Automated Message Spec Preview */}
          <div className="border border-zinc-800 bg-zinc-900/30 rounded-md p-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 pb-3 border-b border-zinc-800 text-xs">
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-white" />
                <span className="font-semibold text-zinc-200">
                  Automatic Daily Reminder Configuration
                </span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full ${
                    isConfigured
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}
                >
                  {isConfigured ? 'Active & Isolated' : 'Missing Contact Info'}
                </span>
              </div>

              {contact?.updatedAt && (
                <div className="flex items-center space-x-1 text-zinc-500 text-[11px]">
                  <Clock className="w-3 h-3" />
                  <span>Last updated: {new Date(contact.updatedAt).toLocaleString()}</span>
                </div>
              )}
            </div>

            {/* Message Template Spec */}
            <div className="mt-3 text-xs">
              <span className="text-[11px] text-zinc-500 uppercase tracking-wider block mb-1">
                Company-Specific Daily Reminder Format:
              </span>
              <div className="p-3 bg-black border border-zinc-800 rounded font-mono text-zinc-300 leading-relaxed">
                &ldquo;Hello{' '}
                <span className="text-white font-bold underline">
                  {company.business_name || contact?.companyName}
                </span>
                , this is a daily reminder from KUBO Finance. Today&apos;s income and profit details
                have not been updated yet. Please update today&apos;s financial details to keep your
                records accurate.&rdquo;
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 mt-2.5 text-[11px] text-zinc-500 font-sans">
                <div>
                  Recipient:{' '}
                  <span className="text-zinc-300 font-mono">
                    {contact?.contactPersonName} &lt;{contact?.emailAddress}&gt; (
                    {contact?.phoneNumber})
                  </span>
                </div>
                <div className="text-zinc-400 font-mono text-[10px]">
                  Duplicate check: Max 1 reminder/day per company
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
