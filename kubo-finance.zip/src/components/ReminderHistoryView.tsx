import React, { useState } from 'react';
import {
  Bell,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Play,
  RotateCcw,
  Mail,
  Phone,
  FileText,
  User,
  Info,
  Server,
  Zap,
} from 'lucide-react';
import { Business, DailyFinancialStatus, ReminderLog, SchedulerRunResult } from '../types';

interface ReminderHistoryViewProps {
  company: Business;
  reminderLogs: ReminderLog[];
  financialStatus: DailyFinancialStatus | null;
  onRefreshLogs: () => void;
}

export const ReminderHistoryView: React.FC<ReminderHistoryViewProps> = ({
  company,
  reminderLogs,
  financialStatus,
  onRefreshLogs,
}) => {
  const [isRunningCheck, setIsRunningCheck] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [lastRunResult, setLastRunResult] = useState<SchedulerRunResult | null>(null);
  const [selectedMessage, setSelectedMessage] = useState<ReminderLog | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const todayDateStr = new Date().toISOString().split('T')[0];

  // Trigger manual execution of the backend daily financial check
  const handleTriggerDailyCheck = async () => {
    setIsRunningCheck(true);
    setFeedback(null);
    try {
      const res = await fetch('/api/reminders/run-daily-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date: todayDateStr }),
      });

      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Daily check execution failed');
      }

      const result: SchedulerRunResult = await res.json();
      setLastRunResult(result);
      onRefreshLogs();
      setFeedback(
        `Automated check executed: ${result.remindersProcessed} reminders created/logged, ${result.skippedAlreadyUpdated} companies up to date, ${result.skippedAlreadySent} duplicate skipped.`,
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setFeedback(`Error running check: ${msg}`);
    } finally {
      setIsRunningCheck(false);
    }
  };

  // Reset today's reminder log for testing duplicate prevention again
  const handleClearTodayReminder = async () => {
    setIsResetting(true);
    try {
      const res = await fetch(`/api/companies/${company.id}/reminders/clear-today`, {
        method: 'POST',
      });
      if (res.ok) {
        onRefreshLogs();
        setFeedback("Today's reminder log cleared for testing.");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="space-y-6 font-mono text-white">
      {/* Header with Scheduler Status */}
      <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-lg">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Bell className="w-5 h-5 text-white" />
              <h2 className="text-base font-bold tracking-tight">
                Daily Financial Reminders &amp; Scheduler
              </h2>
              <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
                Isolated to: {company.business_name}
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-1 font-sans">
              Autonomous background cron runs daily at 00:00 UTC. Verifies income and profit
              records across active companies, delivers company-specific alerts, and prevents
              duplicate messaging.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleClearTodayReminder}
              disabled={isResetting}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-300 rounded transition-colors"
              title="Clears today's reminder record so you can test triggering it again"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isResetting ? 'animate-spin' : ''}`} />
              <span>Reset Today&apos;s Reminder</span>
            </button>

            <button
              onClick={handleTriggerDailyCheck}
              disabled={isRunningCheck}
              className="inline-flex items-center space-x-2 px-4 py-1.5 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded transition-colors disabled:opacity-50"
            >
              <Play className={`w-3.5 h-3.5 ${isRunningCheck ? 'animate-spin' : ''}`} />
              <span>{isRunningCheck ? 'Running Check...' : 'Run Daily Check Now'}</span>
            </button>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div className="mt-4 p-3 bg-zinc-900 border border-zinc-800 rounded text-xs text-zinc-200 flex items-start space-x-2 font-sans">
            <Info className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
            <span>{feedback}</span>
          </div>
        )}
      </div>

      {/* Scheduler Architecture & Live Check Diagnosis Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        {/* Card 1: Today's Financial Verification Status */}
        <div className="bg-black border border-zinc-800 p-4 rounded-lg space-y-2">
          <div className="text-zinc-500 uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
            <Clock className="w-3.5 h-3.5" />
            <span>Company Financial State</span>
          </div>
          <div
            className={`text-sm font-bold ${
              financialStatus?.isFullyUpdated ? 'text-emerald-400' : 'text-amber-400'
            }`}
          >
            {financialStatus?.isFullyUpdated
              ? 'Income & Profit Logged (Compliant)'
              : "Pending Today's Financial Details"}
          </div>
          <div className="text-[11px] text-zinc-400 font-sans leading-relaxed">
            {financialStatus?.isFullyUpdated
              ? 'Scheduler automatically suppresses reminders when records are updated.'
              : 'Missing today’s income or profit records triggers the daily reminder.'}
          </div>
        </div>

        {/* Card 2: Company-Specific Contact Mapping */}
        <div className="bg-black border border-zinc-800 p-4 rounded-lg space-y-2">
          <div className="text-zinc-500 uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
            <User className="w-3.5 h-3.5" />
            <span>Target Contact Mapping</span>
          </div>
          <div className="text-sm font-bold text-white truncate">
            {company.contact?.contactPersonName || 'No Contact Set'}
          </div>
          <div className="text-[11px] text-zinc-400 font-sans truncate">
            {company.contact?.emailAddress} | {company.contact?.phoneNumber}
          </div>
          <div className="text-[10px] text-zinc-500 font-sans">
            Strict isolation: never dispatched to other companies.
          </div>
        </div>

        {/* Card 3: Duplicate Prevention Engine */}
        <div className="bg-black border border-zinc-800 p-4 rounded-lg space-y-2">
          <div className="text-zinc-500 uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-white" />
            <span>Duplicate Prevention</span>
          </div>
          <div className="text-sm font-bold text-white">
            {financialStatus?.reminderSentToday ? (
              <span className="text-blue-400">Processed for Today (Protected)</span>
            ) : (
              <span className="text-zinc-400">0 Sent Today (Eligible)</span>
            )}
          </div>
          <div className="text-[11px] text-zinc-400 font-sans">
            Guarantees at most 1 reminder per company per calendar day.
          </div>
        </div>
      </div>

      {/* Reminder History Table (Company Isolated) */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div>
            <span className="font-bold uppercase tracking-wider text-white">
              Reminder History for {company.business_name}
            </span>
            <span className="text-zinc-500 ml-2">({reminderLogs.length} logged entries)</span>
          </div>
          <div className="text-[11px] text-zinc-400 font-sans flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>Demo Mode Enabled: Message delivery simulated &amp; audited</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black text-zinc-400 text-[11px] uppercase border-b border-zinc-800">
              <tr>
                <th className="p-3.5">Sent / Logged At</th>
                <th className="p-3.5">Target Recipient</th>
                <th className="p-3.5">Channel</th>
                <th className="p-3.5">Message Excerpt</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-center">Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900">
              {reminderLogs.map((log) => {
                const isSentOrLogged = log.status === 'sent' || log.status === 'logged';
                return (
                  <tr key={log.id} className="hover:bg-zinc-900/50 transition-colors">
                    <td className="p-3.5 font-mono text-zinc-300">
                      <div>{new Date(log.sentAt).toLocaleDateString()}</div>
                      <div className="text-[10px] text-zinc-500">
                        {new Date(log.sentAt).toLocaleTimeString()}
                      </div>
                    </td>
                    <td className="p-3.5">
                      <div className="font-semibold text-white">
                        {log.recipient.contactPersonName}
                      </div>
                      <div className="text-[11px] text-zinc-500 font-sans">
                        {log.recipient.emailAddress}
                      </div>
                      <div className="text-[10px] text-zinc-600 font-sans">
                        {log.recipient.phoneNumber}
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[10px] text-zinc-300">
                        {log.channel}
                      </span>
                    </td>
                    <td className="p-3.5 max-w-xs truncate font-sans text-zinc-300">
                      {log.message}
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-sans uppercase font-semibold ${
                          isSentOrLogged
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : 'bg-red-950 text-red-300 border border-red-800'
                        }`}
                      >
                        {log.isDemo && isSentOrLogged ? 'Logged (Demo Mode)' : log.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <button
                        onClick={() => setSelectedMessage(log)}
                        className="text-zinc-400 hover:text-white underline text-[11px]"
                      >
                        View Full
                      </button>
                    </td>
                  </tr>
                );
              })}

              {reminderLogs.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-zinc-500">
                    No reminder records found for this company yet. Click &ldquo;Run Daily Check Now&rdquo; to test.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Message Inspection Modal */}
      {selectedMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-zinc-950 border border-zinc-700 rounded-lg max-w-lg w-full p-6 text-white font-mono space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center space-x-2">
                <Mail className="w-5 h-5 text-white" />
                <span className="font-bold text-sm">Dispatched Reminder Details</span>
              </div>
              <button
                onClick={() => setSelectedMessage(null)}
                className="text-zinc-500 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 bg-black p-3 rounded border border-zinc-800">
                <div>
                  <span className="text-zinc-500 text-[10px] block uppercase">Company</span>
                  <span className="text-white font-semibold">{selectedMessage.companyName}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px] block uppercase">Sent Timestamp</span>
                  <span className="text-zinc-300">{new Date(selectedMessage.sentAt).toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px] block uppercase">Contact Person</span>
                  <span className="text-zinc-300">{selectedMessage.recipient.contactPersonName}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px] block uppercase">Mode</span>
                  <span className="text-emerald-400 font-semibold">
                    {selectedMessage.isDemo ? 'Demo Mode (Simulated)' : 'Production'}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-zinc-400 text-[11px] block uppercase mb-1">
                  Full Message Content:
                </span>
                <div className="p-3.5 bg-black border border-zinc-800 rounded text-zinc-200 font-mono text-xs leading-relaxed">
                  &ldquo;{selectedMessage.message}&rdquo;
                </div>
              </div>

              {selectedMessage.notes && (
                <div>
                  <span className="text-zinc-400 text-[11px] block uppercase mb-1">Audit Log:</span>
                  <div className="p-2.5 bg-zinc-900 rounded text-[11px] text-zinc-400 font-sans">
                    {selectedMessage.notes}
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2 border-t border-zinc-800">
              <button
                onClick={() => setSelectedMessage(null)}
                className="px-4 py-1.5 bg-white text-black font-bold text-xs rounded hover:bg-zinc-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
