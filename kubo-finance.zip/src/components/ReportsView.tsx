import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Download,
  Calendar,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Layers,
} from 'lucide-react';
import { Business, IncomeRecord, ExpenseRecord, InvoiceRecord, PaymentRecord } from '../types';

interface ReportsViewProps {
  company: Business;
  incomes: IncomeRecord[];
  expenses: ExpenseRecord[];
  invoices: InvoiceRecord[];
  payments: PaymentRecord[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  company,
  incomes,
  expenses,
  invoices,
  payments,
}) => {
  const [timeframe, setTimeframe] = useState<'all' | '30d' | '90d' | 'year'>('all');
  const currency = company.currency || 'INR';

  // Filter based on timeframe
  const now = new Date().getTime();
  const filterByTime = (dateStr: string) => {
    if (timeframe === 'all') return true;
    const itemTime = new Date(dateStr).getTime();
    if (isNaN(itemTime)) return true;
    const diffDays = (now - itemTime) / (1000 * 3600 * 24);
    if (timeframe === '30d') return diffDays <= 30;
    if (timeframe === '90d') return diffDays <= 90;
    if (timeframe === 'year') return diffDays <= 365;
    return true;
  };

  const filteredIncomes = incomes.filter((i) => filterByTime(i.income_date));
  const filteredExpenses = expenses.filter((e) => filterByTime(e.expense_date));
  const filteredInvoices = invoices.filter((inv) => filterByTime(inv.issue_date));
  const filteredPayments = payments.filter((p) => filterByTime(p.payment_date));

  // Calculations
  const totalIncome = filteredIncomes.reduce((acc, curr) => acc + Number(curr.amount), 0);
  const totalExpense = filteredExpenses.reduce((acc, curr) => acc + Number(curr.amount), 0);
  const netProfit = totalIncome - totalExpense;
  const profitMargin = totalIncome > 0 ? (netProfit / totalIncome) * 100 : 0;

  const totalInvoiced = filteredInvoices.reduce((acc, curr) => acc + Number(curr.total), 0);
  const paidInvoices = filteredInvoices.filter((inv) => inv.status === 'Paid');
  const paidInvoicesTotal = paidInvoices.reduce((acc, curr) => acc + Number(curr.total), 0);
  const unpaidInvoicesTotal = totalInvoiced - paidInvoicesTotal;
  const totalPaymentsReceived = filteredPayments.reduce((acc, curr) => acc + Number(curr.amount), 0);

  // Category breakdown for Incomes
  const incomeByCategory: { [cat: string]: number } = {};
  filteredIncomes.forEach((i) => {
    const cat = i.category || 'General';
    incomeByCategory[cat] = (incomeByCategory[cat] || 0) + Number(i.amount);
  });

  // Category breakdown for Expenses
  const expenseByCategory: { [cat: string]: number } = {};
  filteredExpenses.forEach((e) => {
    const cat = e.category || 'Other';
    expenseByCategory[cat] = (expenseByCategory[cat] || 0) + Number(e.amount);
  });

  // CSV Export handler
  const handleExportCSV = () => {
    let csv = `KUBO FINANCE AUDIT REPORT\n`;
    csv += `Company,${company.business_name}\n`;
    csv += `Generated,${new Date().toISOString()}\n`;
    csv += `Currency,${currency}\n\n`;

    csv += `SUMMARY METRICS\n`;
    csv += `Total Revenue,${totalIncome}\n`;
    csv += `Total Operating Expenses,${totalExpense}\n`;
    csv += `Net Profit,${netProfit}\n`;
    csv += `Profit Margin,${profitMargin.toFixed(2)}%\n`;
    csv += `Total Invoiced,${totalInvoiced}\n`;
    csv += `Total Payments Collected,${totalPaymentsReceived}\n\n`;

    csv += `INCOME LEDGER\nDate,Description,Category,Amount\n`;
    filteredIncomes.forEach((i) => {
      csv += `"${i.income_date}","${i.description}","${i.category}",${i.amount}\n`;
    });

    csv += `\nEXPENSE LEDGER\nDate,Description,Category,Amount\n`;
    filteredExpenses.forEach((e) => {
      csv += `"${e.expense_date}","${e.description}","${e.category}",${e.amount}\n`;
    });

    csv += `\nINVOICE LEDGER\nInvoice #,Client,Issue Date,Due Date,Status,Total\n`;
    filteredInvoices.forEach((inv) => {
      csv += `"${inv.invoice_number}","${inv.customer_name}","${inv.issue_date}","${inv.due_date}","${inv.status}",${inv.total}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `kubo-report-${company.business_name.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 font-mono text-white">
      {/* Top Banner */}
      <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-white" />
            <h2 className="text-base font-bold tracking-tight">Executive Financial Reports</h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1 font-sans">
            Profitability analysis, balance summaries, and auditing metrics for{' '}
            <strong className="text-white font-mono">{company.business_name}</strong>.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center bg-black border border-zinc-800 rounded p-1 text-xs">
            {(['all', '30d', '90d', 'year'] as const).map((period) => (
              <button
                key={period}
                onClick={() => setTimeframe(period)}
                className={`px-2.5 py-1 rounded transition-colors uppercase text-[10px] ${
                  timeframe === period
                    ? 'bg-zinc-800 text-white font-bold'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {period === 'all' ? 'All Time' : period}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportCSV}
            className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* High Level Key KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Income */}
        <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[10px] uppercase tracking-wider font-bold">Total Revenue</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-3">
            <div className="text-xl font-bold text-white tracking-tight">
              {currency} {totalIncome.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-zinc-500 mt-1 font-sans">
              {filteredIncomes.length} recorded entries
            </div>
          </div>
        </div>

        {/* Total Expenses */}
        <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[10px] uppercase tracking-wider font-bold">Operating Expenses</span>
            <ArrowDownRight className="w-4 h-4 text-rose-400" />
          </div>
          <div className="mt-3">
            <div className="text-xl font-bold text-white tracking-tight">
              {currency} {totalExpense.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-zinc-500 mt-1 font-sans">
              {filteredExpenses.length} cost items
            </div>
          </div>
        </div>

        {/* Net Profit */}
        <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[10px] uppercase tracking-wider font-bold">Net Profit</span>
            <div
              className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                netProfit >= 0 ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'
              }`}
            >
              {profitMargin.toFixed(1)}% margin
            </div>
          </div>
          <div className="mt-3">
            <div
              className={`text-xl font-bold tracking-tight ${
                netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {netProfit < 0 ? '-' : ''}
              {currency} {Math.abs(netProfit).toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-zinc-500 mt-1 font-sans">
              Revenue minus operational costs
            </div>
          </div>
        </div>

        {/* Invoices & Collections */}
        <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[10px] uppercase tracking-wider font-bold">Invoices &amp; Collections</span>
            <Clock className="w-4 h-4 text-blue-400" />
          </div>
          <div className="mt-3">
            <div className="text-xl font-bold text-white tracking-tight">
              {currency} {paidInvoicesTotal.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-zinc-500 mt-1 font-sans">
              {unpaidInvoicesTotal > 0
                ? `${currency} ${unpaidInvoicesTotal.toLocaleString('en-IN')} pending collection`
                : 'All billed invoices collected'}
            </div>
          </div>
        </div>
      </div>

      {/* Category Breakdowns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Income by Category */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
            <span className="text-xs uppercase tracking-wider font-bold text-zinc-300">
              Revenue by Category
            </span>
            <span className="text-[11px] text-zinc-500">
              {Object.keys(incomeByCategory).length} categories
            </span>
          </div>

          <div className="mt-4 space-y-3">
            {Object.entries(incomeByCategory).length > 0 ? (
              Object.entries(incomeByCategory)
                .sort((a, b) => b[1] - a[1])
                .map(([cat, amt]) => {
                  const pct = totalIncome > 0 ? (amt / totalIncome) * 100 : 0;
                  return (
                    <div key={cat} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-300 font-medium">{cat}</span>
                        <span className="text-white font-bold">
                          {currency} {amt.toLocaleString('en-IN')}{' '}
                          <span className="text-[10px] text-zinc-500 font-normal">
                            ({pct.toFixed(1)}%)
                          </span>
                        </span>
                      </div>
                      <div className="h-1.5 w-full bg-zinc-900 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-white rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })
            ) : (
              <p className="text-xs text-zinc-500 py-4 text-center">No income records available.</p>
            )}
          </div>
        </div>

        {/* Expenses by Category */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
            <span className="text-xs uppercase tracking-wider font-bold text-zinc-300">
              Expenditure by Category
            </span>
            <span className="text-[11px] text-zinc-500">
              {Object.keys(expenseByCategory).length} categories
            </span>
          </div>

          <div className="mt-4 space-y-3">
            {Object.entries(expenseByCategory).length > 0 ? (
              Object.entries(expenseByCategory)
                .sort((a, b) => b[1] - a[1])
                .map(([cat, amt]) => {
                  const pct = totalExpense > 0 ? (amt / totalExpense) * 100 : 0;
                  return (
                    <div key={cat} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-300 font-medium">{cat}</span>
                        <span className="text-white font-bold">
                          {currency} {amt.toLocaleString('en-IN')}{' '}
                          <span className="text-[10px] text-zinc-500 font-normal">
                            ({pct.toFixed(1)}%)
                          </span>
                        </span>
                      </div>
                      <div className="h-1.5 w-full bg-zinc-900 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-zinc-400 rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })
            ) : (
              <p className="text-xs text-zinc-500 py-4 text-center">No expense records available.</p>
            )}
          </div>
        </div>
      </div>

      {/* Compliance & Operations Summary */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <span className="text-xs uppercase tracking-wider font-bold text-zinc-300">
            Company Profile &amp; Contact Audit
          </span>
          <span className="text-[11px] text-zinc-500 font-mono">Company ID: {company.id}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mt-4 text-xs">
          <div>
            <span className="text-zinc-500 text-[10px] uppercase block">Registered Name</span>
            <span className="text-white font-bold mt-0.5 block">{company.business_name}</span>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] uppercase block">Designated Contact</span>
            <span className="text-white font-bold mt-0.5 block">
              {company.contact?.contactPersonName || 'Not Set'}
            </span>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] uppercase block">Contact Phone</span>
            <span className="text-zinc-300 mt-0.5 block font-mono">
              {company.contact?.phoneNumber || 'Not Set'}
            </span>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] uppercase block">Contact Email</span>
            <span className="text-zinc-300 mt-0.5 block font-mono">
              {company.contact?.emailAddress || 'Not Set'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
