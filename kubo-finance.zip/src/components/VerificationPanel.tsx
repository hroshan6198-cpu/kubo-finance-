import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Building,
  Play,
  RotateCcw,
  Eye,
  Info,
  Layers,
} from 'lucide-react';
import { Business, DailyFinancialStatus, ReminderLog, SchedulerRunResult } from '../types';

interface VerificationPanelProps {
  companies: Business[];
  currentCompany: Business;
  onSelectCompany: (company: Business) => void;
  onRunDailyCheck: () => Promise<SchedulerRunResult | null>;
  onRefreshAll: () => void;
}

export const VerificationPanel: React.FC<VerificationPanelProps> = ({
  companies,
  currentCompany,
  onSelectCompany,
  onRunDailyCheck,
  onRefreshAll,
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [testResult, setTestResult] = useState<SchedulerRunResult | null>(null);

  const compA = companies.find((c) => c.id === 'comp-apex-101') || companies[0];
  const compB = companies.find((c) => c.id === 'comp-beacon-202') || companies[1];

  const handleExecuteVerification = async () => {
    setIsRunning(true);
    try {
      const res = await onRunDailyCheck();
      setTestResult(res);
      onRefreshAll();
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5 sm:p-6 font-mono text-white space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-white" />
            <h2 className="text-base font-bold tracking-tight">
              Interactive Compliance &amp; Verification Suite
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1 font-sans">
            Validates automatic daily financial checks, company-specific messaging, duplicate prevention, and multi-tenant RLS isolation.
          </p>
        </div>

        <button
          onClick={handleExecuteVerification}
          disabled={isRunning}
          className="inline-flex items-center space-x-2 px-5 py-2 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded transition-colors self-start sm:self-auto disabled:opacity-50"
        >
          <Play className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
          <span>{isRunning ? 'Running Verification Test...' : 'Run Verification Test'}</span>
        </button>
      </div>

      {/* 4 Verification Criteria Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {/* Verification 1: Company A (Missing details -> receives reminder) */}
        <div className="p-4 bg-black border border-zinc-800 rounded-md space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-zinc-500 uppercase text-[10px] tracking-wider">Test Scenario 1</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
              Missing Financials
            </span>
          </div>
          <div className="font-bold text-white text-sm">
            Company A: {compA?.business_name}
          </div>
          <div className="text-[11px] text-zinc-400 font-sans leading-relaxed">
            • <strong>Expected:</strong> Today&apos;s income and profit are missing.
            <br />
            • <strong>Action:</strong> Reminder generated exclusively for {compA?.contact?.contactPersonName} ({compA?.contact?.emailAddress}).
            <br />
            • <strong>Dashboard:</strong> Reminder Card with [Update Now] button visible.
          </div>
          <button
            onClick={() => onSelectCompany(compA)}
            className={`w-full py-1.5 px-3 rounded text-center text-xs font-semibold border transition-colors ${
              currentCompany.id === compA?.id
                ? 'bg-zinc-800 border-zinc-600 text-white'
                : 'bg-zinc-900/60 border-zinc-800 text-zinc-400 hover:text-white'
            }`}
          >
            {currentCompany.id === compA?.id ? 'Currently Viewing (Company A)' : 'Switch to Company A'}
          </button>
        </div>

        {/* Verification 2: Company B (Already updated -> NO reminder) */}
        <div className="p-4 bg-black border border-zinc-800 rounded-md space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-zinc-500 uppercase text-[10px] tracking-wider">Test Scenario 2</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
              Up to Date
            </span>
          </div>
          <div className="font-bold text-white text-sm">
            Company B: {compB?.business_name}
          </div>
          <div className="text-[11px] text-zinc-400 font-sans leading-relaxed">
            • <strong>Expected:</strong> Today&apos;s income and profit are already logged.
            <br />
            • <strong>Action:</strong> Reminder suppressed automatically. No notification sent to {compB?.contact?.contactPersonName}.
            <br />
            • <strong>Dashboard:</strong> Reminder Card suppressed; clean compliant state shown.
          </div>
          <button
            onClick={() => onSelectCompany(compB)}
            className={`w-full py-1.5 px-3 rounded text-center text-xs font-semibold border transition-colors ${
              currentCompany.id === compB?.id
                ? 'bg-zinc-800 border-zinc-600 text-white'
                : 'bg-zinc-900/60 border-zinc-800 text-zinc-400 hover:text-white'
            }`}
          >
            {currentCompany.id === compB?.id ? 'Currently Viewing (Company B)' : 'Switch to Company B'}
          </button>
        </div>

        {/* Verification 3: Data Isolation */}
        <div className="p-4 bg-black border border-zinc-800 rounded-md space-y-2">
          <div className="flex items-center space-x-1.5 text-zinc-500 uppercase text-[10px] tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Test Scenario 3: Data Isolation &amp; Security</span>
          </div>
          <div className="text-[11px] text-zinc-300 font-sans leading-relaxed">
            Every company can only query and view its own contact details, financial entries,
            invoices, and reminder histories. Company A cannot view or manipulate Company B&apos;s
            records.
          </div>
        </div>

        {/* Verification 4: Duplicate Prevention */}
        <div className="p-4 bg-black border border-zinc-800 rounded-md space-y-2">
          <div className="flex items-center space-x-1.5 text-zinc-500 uppercase text-[10px] tracking-wider">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
            <span>Test Scenario 4: Duplicate Prevention</span>
          </div>
          <div className="text-[11px] text-zinc-300 font-sans leading-relaxed">
            A company receives at most one automated reminder per calendar day. Once processed,
            subsequent scheduler triggers recognize the existing record and skip dispatching.
          </div>
        </div>
      </div>

      {/* Test Run Output Summary (if run) */}
      {testResult && (
        <div className="border border-zinc-800 bg-black p-4 rounded-md space-y-3">
          <div className="flex items-center justify-between text-xs border-b border-zinc-900 pb-2">
            <span className="font-bold uppercase text-white">Live Check Execution Output</span>
            <span className="text-zinc-500 text-[11px]">{new Date(testResult.runAt).toLocaleTimeString()}</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs font-mono">
            <div className="p-2 bg-zinc-950 border border-zinc-900 rounded">
              <span className="text-[10px] text-zinc-500 block">Total Companies</span>
              <span className="text-base font-bold text-white">{testResult.totalCompaniesChecked}</span>
            </div>
            <div className="p-2 bg-zinc-950 border border-zinc-900 rounded">
              <span className="text-[10px] text-zinc-500 block">Reminders Logged</span>
              <span className="text-base font-bold text-emerald-400">{testResult.remindersProcessed}</span>
            </div>
            <div className="p-2 bg-zinc-950 border border-zinc-900 rounded">
              <span className="text-[10px] text-zinc-500 block">Already Updated</span>
              <span className="text-base font-bold text-blue-400">{testResult.skippedAlreadyUpdated}</span>
            </div>
            <div className="p-2 bg-zinc-950 border border-zinc-900 rounded">
              <span className="text-[10px] text-zinc-500 block">Duplicate Skipped</span>
              <span className="text-base font-bold text-zinc-400">{testResult.skippedAlreadySent}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
