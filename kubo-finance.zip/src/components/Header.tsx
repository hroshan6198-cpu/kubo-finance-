import React from 'react';
import {
  Building2,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  RefreshCw,
  Bell,
  ShieldCheck,
} from 'lucide-react';
import { Business, DailyFinancialStatus } from '../types';

interface HeaderProps {
  companies: Business[];
  currentCompany: Business | null;
  onSelectCompany: (company: Business) => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  financialStatus: DailyFinancialStatus | null;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  companies,
  currentCompany,
  onSelectCompany,
  activeTab,
  onSelectTab,
  financialStatus,
  onRefresh,
  isRefreshing,
}) => {
  const [dropdownOpen, setDropdownOpen] = React.useState(false);

  const todayFormatted = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <header className="border-b border-zinc-800 bg-black text-white sticky top-0 z-30">
      {/* Top Banner / System Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Tagline */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-white text-black font-black flex items-center justify-center text-sm tracking-tighter rounded-sm">
                KB
              </div>
              <div>
                <span className="font-mono font-bold tracking-wider text-base text-white">
                  KUBO FINANCE
                </span>
                <span className="hidden sm:inline-block ml-2 text-xs text-zinc-400 font-mono border-l border-zinc-700 pl-2">
                  Part of KUBO Tech Ecosystem
                </span>
              </div>
            </div>
          </div>

          {/* Center / Right controls */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            {/* Date display */}
            <div className="hidden md:flex items-center space-x-1.5 px-3 py-1 rounded-md bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 font-mono">
              <Calendar className="w-3.5 h-3.5 text-zinc-400" />
              <span>{todayFormatted}</span>
            </div>

            {/* Financial Status Indicator for Active Company */}
            {financialStatus && (
              <div
                className={`hidden lg:flex items-center space-x-1.5 px-2.5 py-1 rounded-md border text-xs font-mono ${
                  financialStatus.isFullyUpdated
                    ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
                    : 'bg-amber-950/40 border-amber-800 text-amber-300'
                }`}
                title={
                  financialStatus.isFullyUpdated
                    ? "Today's income and profit records are up to date."
                    : "Today's financial update is pending."
                }
              >
                {financialStatus.isFullyUpdated ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                )}
                <span>
                  {financialStatus.isFullyUpdated ? "Today's Data: Complete" : "Today's Data: Missing"}
                </span>
              </div>
            )}

            {/* Refresh Button */}
            <button
              onClick={onRefresh}
              disabled={isRefreshing}
              className="p-1.5 rounded-md hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors border border-zinc-800"
              title="Refresh Data & Status"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-white' : ''}`} />
            </button>

            {/* Company Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center space-x-2 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-white rounded-md transition-all font-mono"
              >
                <Building2 className="w-3.5 h-3.5 text-zinc-400" />
                <span className="max-w-[130px] sm:max-w-[180px] truncate font-semibold">
                  {currentCompany?.business_name || 'Select Company'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
              </button>

              {dropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-zinc-950 border border-zinc-700 rounded-md shadow-2xl py-2 z-50 text-xs font-mono">
                  <div className="px-3 py-1.5 border-b border-zinc-800 text-[10px] uppercase text-zinc-500 font-semibold tracking-wider">
                    Switch Active Company (Data Isolation)
                  </div>
                  {companies.map((comp) => {
                    const isSelected = comp.id === currentCompany?.id;
                    const isApex = comp.id === 'comp-apex-101';
                    return (
                      <button
                        key={comp.id}
                        onClick={() => {
                          onSelectCompany(comp);
                          setDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2.5 flex flex-col hover:bg-zinc-900 transition-colors ${
                          isSelected ? 'bg-zinc-900/80 border-l-2 border-white' : ''
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-white truncate">{comp.business_name}</span>
                          {isSelected && <span className="text-[10px] text-zinc-400 font-normal">Active</span>}
                        </div>
                        <div className="flex items-center space-x-2 mt-0.5 text-[11px] text-zinc-400">
                          <span>{comp.contact?.contactPersonName || 'No Contact'}</span>
                          <span>•</span>
                          <span
                            className={
                              isApex ? 'text-amber-400 font-medium' : 'text-emerald-400 font-medium'
                            }
                          >
                            {isApex ? 'Pending Details (Reminds)' : 'Details Logged (No Reminder)'}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                  <div className="px-3 pt-2 mt-1 border-t border-zinc-800 text-[10px] text-zinc-400 flex items-center space-x-1">
                    <ShieldCheck className="w-3 h-3 text-zinc-400" />
                    <span>Strict RLS Tenant Isolation Enforced</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Navigation Bar */}
        <nav className="flex space-x-1 sm:space-x-4 overflow-x-auto py-2 border-t border-zinc-800/80 scrollbar-none text-xs font-mono">
          {[
            { id: 'dashboard', label: 'Dashboard' },
            { id: 'contacts', label: 'Company & Contacts' },
            { id: 'incomes', label: "Incomes & Profits" },
            { id: 'expenses', label: 'Expenses' },
            { id: 'invoices', label: 'Invoices & Payments' },
            { id: 'reports', label: 'Reports & Auditing' },
            { id: 'reminders', label: 'Reminder Logs & Scheduler' },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-colors relative font-medium ${
                  isActive
                    ? 'bg-white text-black font-semibold'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                {tab.label}
                {tab.id === 'reminders' && financialStatus?.needsReminder && (
                  <span className="ml-1.5 inline-block w-1.5 h-1.5 rounded-full bg-amber-400" />
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
