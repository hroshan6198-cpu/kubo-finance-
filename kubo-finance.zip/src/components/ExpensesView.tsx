import React, { useState } from 'react';
import { Tag, Plus, Trash2, Edit2, Search, Filter, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Business, DailyFinancialStatus, ExpenseRecord } from '../types';
import { EditExpenseModal } from './EditExpenseModal';
import { ConfirmDeleteModal } from './ConfirmDeleteModal';

interface ExpensesViewProps {
  company: Business;
  expenses: ExpenseRecord[];
  financialStatus: DailyFinancialStatus | null;
  onExpenseAdded: () => void;
  onExpenseUpdated: () => void;
  onExpenseDeleted: (id: string) => void;
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  company,
  expenses,
  financialStatus,
  onExpenseAdded,
  onExpenseUpdated,
  onExpenseDeleted,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Software');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filter & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  // Edit & Delete
  const [editingExpense, setEditingExpense] = useState<ExpenseRecord | null>(null);
  const [deletingExpense, setDeletingExpense] = useState<ExpenseRecord | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const currency = company.currency || 'INR';

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) {
      setError('Amount must be greater than 0.');
      return;
    }
    if (!description.trim()) {
      setError('Description is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/companies/${company.id}/expenses`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: num,
          description: description.trim(),
          category,
          expense_date: date,
        }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to add expense');
      }
      setAmount('');
      setDescription('');
      setShowAddForm(false);
      onExpenseAdded();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveEdit = async (
    id: string,
    data: { amount: number; description: string; category: string; expense_date: string }
  ) => {
    const res = await fetch(`/api/companies/${company.id}/expenses/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const d = await res.json();
      throw new Error(d.error || 'Failed to update expense');
    }
    onExpenseUpdated();
  };

  const handleConfirmDelete = async () => {
    if (!deletingExpense) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/companies/${company.id}/expenses/${deletingExpense.id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        onExpenseDeleted(deletingExpense.id);
        setDeletingExpense(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredExpenses = expenses.filter((exp) => {
    const matchesSearch =
      exp.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.expense_date.includes(searchTerm);
    const matchesCat = categoryFilter === 'ALL' || exp.category === categoryFilter;
    return matchesSearch && matchesCat;
  });

  const total = filteredExpenses.reduce((acc, curr) => acc + Number(curr.amount), 0);
  const allCategories = Array.from(new Set(expenses.map((e) => e.category)));

  return (
    <div className="space-y-6 font-mono text-white">
      {/* Banner */}
      <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Tag className="w-5 h-5 text-white" />
            <h2 className="text-base font-bold tracking-tight">Operating Expenses</h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1 font-sans">
            Operating expenditure, vendor bills, and cost tracking for{' '}
            <strong className="text-white font-mono">{company.business_name}</strong>.
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="inline-flex items-center space-x-1.5 px-4 py-1.5 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Record Expense</span>
        </button>
      </div>

      {/* Add Form */}
      {showAddForm && (
        <form onSubmit={handleAdd} className="bg-black border border-zinc-700 p-5 rounded-lg space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
            <span className="font-bold uppercase tracking-wider text-white">New Expense Entry</span>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-zinc-400 hover:text-white"
            >
              Cancel
            </button>
          </div>

          {error && <div className="p-2 bg-red-950 text-red-300 rounded border border-red-800">{error}</div>}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-zinc-400 text-[10px] uppercase mb-1">Amount ({currency}) *</label>
              <input
                type="number"
                step="any"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="15000"
                required
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white font-mono focus:border-white outline-none"
              />
            </div>
            <div>
              <label className="block text-zinc-400 text-[10px] uppercase mb-1">Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white focus:border-white outline-none"
              >
                <option value="Software">Software &amp; Tools</option>
                <option value="Infrastructure">Cloud &amp; Hosting</option>
                <option value="Office">Office &amp; Admin</option>
                <option value="Salaries">Payroll &amp; Contractors</option>
                <option value="Marketing">Marketing &amp; Ads</option>
                <option value="Travel">Travel &amp; Logistics</option>
                <option value="Legal">Legal &amp; Compliance</option>
                <option value="Other">Other Expenses</option>
              </select>
            </div>
            <div>
              <label className="block text-zinc-400 text-[10px] uppercase mb-1">Expense Date *</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white focus:border-white outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-zinc-400 text-[10px] uppercase mb-1">Description *</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. AWS monthly cloud server charges"
              required
              className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 text-white focus:border-white outline-none"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-zinc-800 rounded text-zinc-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-white text-black font-bold rounded hover:bg-zinc-200"
            >
              {isSubmitting ? 'Recording...' : 'Record Expense'}
            </button>
          </div>
        </form>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-zinc-950 border border-zinc-800 p-3 rounded-lg text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search expenses, vendors..."
            className="w-full bg-black border border-zinc-800 rounded pl-9 pr-3 py-1.5 text-white font-mono focus:border-white outline-none"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-zinc-500" />
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-black border border-zinc-800 rounded px-2.5 py-1.5 text-white font-mono text-xs focus:border-white outline-none"
          >
            <option value="ALL">All Categories</option>
            {allCategories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Expense Records Table */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
          <span className="text-xs uppercase tracking-wider text-zinc-400">
            Recorded Expenses ({filteredExpenses.length})
          </span>
          <span className="text-xs font-bold text-white">
            Total: {currency} {total.toLocaleString('en-IN')}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black text-zinc-400 text-[11px] uppercase border-b border-zinc-800">
              <tr>
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Description</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5 text-right">Amount</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900">
              {filteredExpenses.map((exp) => (
                <tr key={exp.id} className="hover:bg-zinc-900/50 transition-colors">
                  <td className="p-3.5 font-mono text-zinc-300">{exp.expense_date}</td>
                  <td className="p-3.5 font-semibold text-white">{exp.description}</td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[10px] text-zinc-300">
                      {exp.category}
                    </span>
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-rose-400">
                    -{currency} {Number(exp.amount).toLocaleString('en-IN')}
                  </td>
                  <td className="p-3.5 text-center">
                    <div className="flex items-center justify-center space-x-1">
                      <button
                        onClick={() => setEditingExpense(exp)}
                        className="text-zinc-400 hover:text-white p-1 rounded transition-colors"
                        title="Edit Expense"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeletingExpense(exp)}
                        className="text-zinc-400 hover:text-rose-400 p-1 rounded transition-colors"
                        title="Delete Expense"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {filteredExpenses.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-10 text-center text-zinc-500">
                    <p className="text-xs">No expense records found.</p>
                    <button
                      onClick={() => setShowAddForm(true)}
                      className="mt-3 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs rounded font-bold"
                    >
                      + Add New Expense Entry
                    </button>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Expense Modal */}
      <EditExpenseModal
        isOpen={Boolean(editingExpense)}
        expense={editingExpense}
        currency={currency}
        onClose={() => setEditingExpense(null)}
        onSave={handleSaveEdit}
      />

      {/* Delete Confirmation Modal */}
      <ConfirmDeleteModal
        isOpen={Boolean(deletingExpense)}
        onClose={() => setDeletingExpense(null)}
        onConfirm={handleConfirmDelete}
        title="Delete this record?"
        message={`Are you sure you want to delete the expense entry "${deletingExpense?.description}" of ${currency} ${deletingExpense?.amount?.toLocaleString('en-IN')}? This action cannot be undone.`}
        confirmLabel="Delete"
        cancelLabel="Cancel"
        isDeleting={isDeleting}
      />
    </div>
  );
};
