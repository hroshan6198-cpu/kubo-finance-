/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { CompanyContactSection } from './components/CompanyContactSection';
import { CompaniesManagementView } from './components/CompaniesManagementView';
import { IncomesProfitsView } from './components/IncomesProfitsView';
import { ExpensesView } from './components/ExpensesView';
import { InvoicesView } from './components/InvoicesView';
import { ReportsView } from './components/ReportsView';
import { ReminderHistoryView } from './components/ReminderHistoryView';
import { VerificationPanel } from './components/VerificationPanel';
import { FinancialEntryModal } from './components/FinancialEntryModal';
import { ToastContainer, ToastMessage } from './components/Toast';
import {
  Business,
  DailyFinancialStatus,
  ExpenseRecord,
  IncomeRecord,
  InvoiceRecord,
  PaymentRecord,
  ReminderLog,
  SchedulerRunResult,
} from './types';
import { ShieldCheck, RefreshCw, Building2, User } from 'lucide-react';

export default function App() {
  const [companies, setCompanies] = useState<Business[]>([]);
  const [currentCompany, setCurrentCompany] = useState<Business | null>(null);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [contactsSubTab, setContactsSubTab] = useState<'profile' | 'allCompanies'>('profile');

  // Company isolated records
  const [financialStatus, setFinancialStatus] = useState<DailyFinancialStatus | null>(null);
  const [incomes, setIncomes] = useState<IncomeRecord[]>([]);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>([]);
  const [invoices, setInvoices] = useState<InvoiceRecord[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [reminderLogs, setReminderLogs] = useState<ReminderLog[]>([]);

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Modal and loading states
  const [isFinancialModalOpen, setIsFinancialModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isTriggeringCheck, setIsTriggeringCheck] = useState(false);

  const showToast = useCallback(
    (type: 'success' | 'error' | 'info', message: string, description?: string) => {
      const newToast: ToastMessage = {
        id: `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        type,
        message,
        description,
      };
      setToasts((prev) => [...prev, newToast]);
    },
    [],
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Fetch all companies on initial load
  const loadCompanies = useCallback(async () => {
    try {
      const res = await fetch('/api/companies');
      if (!res.ok) throw new Error('Failed to fetch companies');
      const data: Business[] = await res.json();
      setCompanies(data);
      if (data.length > 0 && !currentCompany) {
        // Default to Apex Tech Labs
        const defaultComp = data.find((c) => c.id === 'comp-apex-101') || data[0];
        setCurrentCompany(defaultComp);
      }
    } catch (err) {
      console.error('Error fetching companies:', err);
    } finally {
      setIsLoading(false);
    }
  }, [currentCompany]);

  useEffect(() => {
    loadCompanies();
  }, [loadCompanies]);

  // Fetch all company-scoped data whenever currentCompany changes
  const loadCompanyData = useCallback(async (companyId: string) => {
    setIsRefreshing(true);
    try {
      const [statusRes, incRes, expRes, invRes, payRes, remRes] = await Promise.all([
        fetch(`/api/companies/${companyId}/financial-status`),
        fetch(`/api/companies/${companyId}/incomes`),
        fetch(`/api/companies/${companyId}/expenses`),
        fetch(`/api/companies/${companyId}/invoices`),
        fetch(`/api/companies/${companyId}/payments`),
        fetch(`/api/companies/${companyId}/reminders`),
      ]);

      if (statusRes.ok) setFinancialStatus(await statusRes.json());
      if (incRes.ok) setIncomes(await incRes.json());
      if (expRes.ok) setExpenses(await expRes.json());
      if (invRes.ok) setInvoices(await invRes.json());
      if (payRes.ok) setPayments(await payRes.json());
      if (remRes.ok) setReminderLogs(await remRes.json());
    } catch (err) {
      console.error('Error fetching company details:', err);
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    if (currentCompany) {
      loadCompanyData(currentCompany.id);
    }
  }, [currentCompany, loadCompanyData]);

  // Handle switching company (enforcing strict data isolation)
  const handleSelectCompany = (comp: Business) => {
    setCurrentCompany(comp);
    showToast(
      'info',
      `Switched to ${comp.business_name}`,
      'Loaded isolated records, contacts, and reminder history.',
    );
  };

  // Handle company contact updated
  const handleContactUpdated = (updated: Business) => {
    setCurrentCompany(updated);
    setCompanies((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    showToast('success', 'Company contact updated successfully.');
  };

  // Company management CRUD handlers
  const handleCompanyCreated = (newComp: Business) => {
    setCompanies((prev) => [...prev, newComp]);
    setCurrentCompany(newComp);
    showToast('success', `Created company "${newComp.business_name}".`);
  };

  const handleCompanyUpdated = (updatedComp: Business) => {
    setCompanies((prev) => prev.map((c) => (c.id === updatedComp.id ? updatedComp : c)));
    if (currentCompany?.id === updatedComp.id) {
      setCurrentCompany(updatedComp);
    }
  };

  const handleCompanyDeleted = (deletedId: string) => {
    setCompanies((prev) => {
      const remaining = prev.filter((c) => c.id !== deletedId);
      if (currentCompany?.id === deletedId && remaining.length > 0) {
        setCurrentCompany(remaining[0]);
      }
      return remaining;
    });
  };

  const handleFinancialDataCleared = (companyId: string) => {
    if (currentCompany?.id === companyId) {
      loadCompanyData(companyId);
    }
  };

  // Handle financial entries updated (income / expenses)
  const handleFinancialsUpdated = () => {
    if (currentCompany) {
      loadCompanyData(currentCompany.id);
      showToast('success', "Today's financial details updated.", 'Daily compliance verified.');
    }
  };

  // Trigger manual daily check
  const handleTriggerDailyCheck = async (): Promise<SchedulerRunResult | null> => {
    setIsTriggeringCheck(true);
    try {
      const res = await fetch('/api/reminders/run-daily-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error('Check execution failed');
      const data: SchedulerRunResult = await res.json();
      if (currentCompany) {
        await loadCompanyData(currentCompany.id);
      }
      showToast(
        'info',
        'Daily Check Complete',
        `${data.remindersProcessed} sent, ${data.skippedAlreadyUpdated} updated, ${data.skippedAlreadySent} duplicate skipped.`,
      );
      return data;
    } catch (err) {
      console.error('Error triggering daily check:', err);
      showToast('error', 'Daily check failed to execute.');
      return null;
    } finally {
      setIsTriggeringCheck(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center font-mono text-sm">
        <div className="flex items-center space-x-3">
          <RefreshCw className="w-5 h-5 animate-spin text-zinc-400" />
          <span>Initializing KUBO Finance Engine...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-zinc-100 flex flex-col font-sans selection:bg-white selection:text-black">
      {/* Toast Notification Stack */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* App Header & Navigation */}
      <Header
        companies={companies}
        currentCompany={currentCompany}
        onSelectCompany={handleSelectCompany}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        financialStatus={financialStatus}
        onRefresh={() => currentCompany && loadCompanyData(currentCompany.id)}
        isRefreshing={isRefreshing}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {currentCompany ? (
          <>
            {/* 1. Dashboard View */}
            {activeTab === 'dashboard' && (
              <Dashboard
                company={currentCompany}
                financialStatus={financialStatus}
                incomes={incomes}
                expenses={expenses}
                invoices={invoices}
                payments={payments}
                onOpenFinancialUpdate={() => setIsFinancialModalOpen(true)}
                onNavigateTab={setActiveTab}
                onTriggerDailyCheck={handleTriggerDailyCheck}
                isTriggeringCheck={isTriggeringCheck}
              />
            )}

            {/* 2. Company & Contacts Management View */}
            {activeTab === 'contacts' && (
              <div className="space-y-6">
                {/* Sub-navigation for Contacts */}
                <div className="flex items-center space-x-2 border-b border-zinc-800 pb-2 text-xs font-mono">
                  <button
                    onClick={() => setContactsSubTab('profile')}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-colors ${
                      contactsSubTab === 'profile'
                        ? 'bg-white text-black font-bold'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                    }`}
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>Active Company Contact</span>
                  </button>
                  <button
                    onClick={() => setContactsSubTab('allCompanies')}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-colors ${
                      contactsSubTab === 'allCompanies'
                        ? 'bg-white text-black font-bold'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                    }`}
                  >
                    <Building2 className="w-3.5 h-3.5" />
                    <span>All Companies Directory ({companies.length})</span>
                  </button>
                </div>

                {contactsSubTab === 'profile' ? (
                  <>
                    <CompanyContactSection
                      company={currentCompany}
                      onContactUpdated={handleContactUpdated}
                      onRequestTestReminder={handleTriggerDailyCheck}
                    />

                    {/* Verification Suite Panel */}
                    <VerificationPanel
                      companies={companies}
                      currentCompany={currentCompany}
                      onSelectCompany={handleSelectCompany}
                      onRunDailyCheck={handleTriggerDailyCheck}
                      onRefreshAll={() => loadCompanyData(currentCompany.id)}
                    />
                  </>
                ) : (
                  <CompaniesManagementView
                    companies={companies}
                    activeCompany={currentCompany}
                    onSelectCompany={handleSelectCompany}
                    onCompanyCreated={handleCompanyCreated}
                    onCompanyUpdated={handleCompanyUpdated}
                    onCompanyDeleted={handleCompanyDeleted}
                    onFinancialDataCleared={handleFinancialDataCleared}
                    showToast={showToast}
                  />
                )}
              </div>
            )}

            {/* 3. Incomes & Profits View */}
            {activeTab === 'incomes' && (
              <IncomesProfitsView
                company={currentCompany}
                incomes={incomes}
                financialStatus={financialStatus}
                onIncomeAdded={handleFinancialsUpdated}
                onIncomeUpdated={handleFinancialsUpdated}
                onIncomeDeleted={(id) => {
                  loadCompanyData(currentCompany.id);
                  showToast('info', 'Income record deleted successfully.');
                }}
                onOpenQuickEntry={() => setIsFinancialModalOpen(true)}
              />
            )}

            {/* 4. Expenses View */}
            {activeTab === 'expenses' && (
              <ExpensesView
                company={currentCompany}
                expenses={expenses}
                financialStatus={financialStatus}
                onExpenseAdded={handleFinancialsUpdated}
                onExpenseUpdated={handleFinancialsUpdated}
                onExpenseDeleted={(id) => {
                  loadCompanyData(currentCompany.id);
                  showToast('info', 'Expense record deleted successfully.');
                }}
              />
            )}

            {/* 5. Invoices & Payments View */}
            {activeTab === 'invoices' && (
              <InvoicesView
                company={currentCompany}
                invoices={invoices}
                payments={payments}
                onInvoiceCreated={() => {
                  loadCompanyData(currentCompany.id);
                  showToast('success', 'Invoice generated and registered.');
                }}
                onInvoiceUpdated={() => {
                  loadCompanyData(currentCompany.id);
                  showToast('success', 'Invoice updated successfully.');
                }}
                onInvoiceDeleted={(id) => {
                  loadCompanyData(currentCompany.id);
                  showToast('info', 'Invoice deleted.');
                }}
                onPaymentAdded={() => {
                  loadCompanyData(currentCompany.id);
                  showToast('success', 'Client payment recorded successfully.');
                }}
                onPaymentDeleted={(id) => {
                  loadCompanyData(currentCompany.id);
                  showToast('info', 'Payment record deleted.');
                }}
              />
            )}

            {/* 6. Reports & Auditing View */}
            {activeTab === 'reports' && (
              <ReportsView
                company={currentCompany}
                incomes={incomes}
                expenses={expenses}
                invoices={invoices}
                payments={payments}
              />
            )}

            {/* 7. Reminder Logs & Scheduler View */}
            {activeTab === 'reminders' && (
              <div className="space-y-6">
                <ReminderHistoryView
                  company={currentCompany}
                  reminderLogs={reminderLogs}
                  financialStatus={financialStatus}
                  onRefreshLogs={() => loadCompanyData(currentCompany.id)}
                />

                <VerificationPanel
                  companies={companies}
                  currentCompany={currentCompany}
                  onSelectCompany={handleSelectCompany}
                  onRunDailyCheck={handleTriggerDailyCheck}
                  onRefreshAll={() => loadCompanyData(currentCompany.id)}
                />
              </div>
            )}
          </>
        ) : (
          <div className="p-8 text-center text-zinc-500 font-mono text-sm">
            No company selected.
          </div>
        )}
      </main>

      {/* Financial Entry Modal (Triggered by [Update Now]) */}
      {currentCompany && (
        <FinancialEntryModal
          isOpen={isFinancialModalOpen}
          onClose={() => setIsFinancialModalOpen(false)}
          company={currentCompany}
          financialStatus={financialStatus}
          onFinancialsUpdated={handleFinancialsUpdated}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-zinc-900 bg-black py-4 px-4 sm:px-8 text-xs font-mono text-zinc-600 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-3.5 h-3.5 text-zinc-500" />
          <span>KUBO Finance • Multi-Tenant Row Level Security Active</span>
        </div>
        <div>Invoices, payment reminders, expense tracking &amp; audit reports.</div>
      </footer>
    </div>
  );
}
