export interface MessageRecipient {
  contactPersonName: string;
  phoneNumber: string;
  emailAddress: string;
}

export interface MessagePayload {
  companyId: string;
  companyName: string;
  recipient: MessageRecipient;
  message: string;
  channel?: 'SMS' | 'Email' | 'WhatsApp' | 'Multi-Channel (Demo)';
}

export interface MessageDeliveryResult {
  success: boolean;
  status: 'sent' | 'logged' | 'failed_provider_error';
  isDemo: boolean;
  channel: 'SMS' | 'Email' | 'WhatsApp' | 'Multi-Channel (Demo)';
  providerName: string;
  deliveredTo: {
    name: string;
    phone: string;
    email: string;
  };
  timestamp: string;
  logSummary: string;
  error?: string;
}

export interface IMessageProvider {
  name: string;
  isConfigured(): boolean;
  sendMessage(payload: MessagePayload): Promise<MessageDeliveryResult>;
}

/**
 * Standard KUBO Finance reminder message generator
 */
export function buildReminderMessage(companyName?: string): string {
  if (companyName && companyName.trim().length > 0) {
    return `Hello ${companyName.trim()}, this is a daily reminder from KUBO Finance. Today's income and profit details have not been updated yet. Please update today's financial details to keep your records accurate.`;
  }
  return "Daily Reminder – KUBO Finance: Today's income and profit details have not been updated yet. Please update today's financial details to keep your records accurate.";
}

/**
 * Demo Message Provider (Default in non-production / test environments)
 * Strictly does not dispatch external network SMS/emails, but provides
 * full auditing, logging, and in-app display of intended messages.
 */
export class DemoMessageProvider implements IMessageProvider {
  public name = 'KUBO Demo Multi-Channel Engine';

  public isConfigured(): boolean {
    return true;
  }

  public async sendMessage(payload: MessagePayload): Promise<MessageDeliveryResult> {
    const timestamp = new Date().toISOString();
    const { recipient, companyName, message } = payload;

    const logSummary = `[DEMO MODE] Automated Daily Financial Reminder logged for "${companyName}". Recipient: ${recipient.contactPersonName} | Phone: ${recipient.phoneNumber} | Email: ${recipient.emailAddress}`;
    console.log(`[KUBO Finance Scheduler] ${logSummary}`);
    console.log(`[KUBO Finance Message Content]:\n"${message}"\n`);

    return {
      success: true,
      status: 'logged',
      isDemo: true,
      channel: payload.channel || 'Multi-Channel (Demo)',
      providerName: this.name,
      deliveredTo: {
        name: recipient.contactPersonName,
        phone: recipient.phoneNumber,
        email: recipient.emailAddress,
      },
      timestamp,
      logSummary,
    };
  }
}

/**
 * Modular Email Provider (Ready for SMTP / SendGrid)
 */
export class EmailMessageProvider implements IMessageProvider {
  public name = 'SMTP / Email Provider';

  public isConfigured(): boolean {
    return !!(process.env.SMTP_HOST || process.env.SENDGRID_API_KEY);
  }

  public async sendMessage(payload: MessagePayload): Promise<MessageDeliveryResult> {
    if (!this.isConfigured()) {
      // Fall back to demo provider if not configured
      const demo = new DemoMessageProvider();
      return demo.sendMessage({ ...payload, channel: 'Email' });
    }

    // Production email dispatch logic placeholder
    return {
      success: true,
      status: 'sent',
      isDemo: false,
      channel: 'Email',
      providerName: this.name,
      deliveredTo: {
        name: payload.recipient.contactPersonName,
        phone: payload.recipient.phoneNumber,
        email: payload.recipient.emailAddress,
      },
      timestamp: new Date().toISOString(),
      logSummary: `Email sent via ${this.name} to ${payload.recipient.emailAddress}`,
    };
  }
}

/**
 * Modular SMS Provider (Ready for Twilio / AWS SNS)
 */
export class SMSMessageProvider implements IMessageProvider {
  public name = 'SMS Gateway Provider';

  public isConfigured(): boolean {
    return !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN);
  }

  public async sendMessage(payload: MessagePayload): Promise<MessageDeliveryResult> {
    if (!this.isConfigured()) {
      const demo = new DemoMessageProvider();
      return demo.sendMessage({ ...payload, channel: 'SMS' });
    }

    return {
      success: true,
      status: 'sent',
      isDemo: false,
      channel: 'SMS',
      providerName: this.name,
      deliveredTo: {
        name: payload.recipient.contactPersonName,
        phone: payload.recipient.phoneNumber,
        email: payload.recipient.emailAddress,
      },
      timestamp: new Date().toISOString(),
      logSummary: `SMS dispatched to ${payload.recipient.phoneNumber}`,
    };
  }
}

/**
 * Messaging Service Router
 */
export class MessagingService {
  private activeProvider: IMessageProvider;

  constructor(provider?: IMessageProvider) {
    this.activeProvider = provider || new DemoMessageProvider();
  }

  public setProvider(provider: IMessageProvider) {
    this.activeProvider = provider;
  }

  public getProviderName(): string {
    return this.activeProvider.name;
  }

  public async dispatchReminder(payload: MessagePayload): Promise<MessageDeliveryResult> {
    return this.activeProvider.sendMessage(payload);
  }
}

export const messagingService = new MessagingService();
