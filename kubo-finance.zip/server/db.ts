import {
  Business,
  CompanyContact,
  DailyFinancialStatus,
  ExpenseRecord,
  IncomeRecord,
  InvoiceRecord,
  PaymentRecord,
  Profile,
  ReminderLog,
} from '../src/types';

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getYesterdayDateString(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

class InMemoryKuboDatabase {
  private profiles: Profile[] = [];
  private businesses: Business[] = [];
  private incomes: IncomeRecord[] = [];
  private expenses: ExpenseRecord[] = [];
  private invoices: InvoiceRecord[] = [];
  private payments: PaymentRecord[] = [];
  private reminderLogs: ReminderLog[] = [];

  constructor() {
    this.seedInitialData();
  }

  private seedInitialData() {
    const today = getTodayDateString();
    const yesterday = getYesterdayDateString();

    // Profiles
    this.profiles = [
      {
        id: 'usr-apex-01',
        full_name: 'Rajesh Sharma',
        email: 'rajesh.sharma@apextech.io',
        phone: '+91 98201 54321',
        business_name: 'Apex Technologies Pvt Ltd',
        profile_edit_count: 0,
        role: 'customer',
        created_at: new Date(Date.now() - 30 * 86400000).toISOString(),
        updated_at: new Date().toISOString(),
      },
      {
        id: 'usr-beacon-02',
        full_name: 'Anita Roy',
        email: 'anita.roy@beaconstudio.design',
        phone: '+91 98450 11223',
        business_name: 'Beacon Creative Studio',
        profile_edit_count: 0,
        role: 'customer',
        created_at: new Date(Date.now() - 45 * 86400000).toISOString(),
        updated_at: new Date().toISOString(),
      },
    ];

    // Businesses with initial Contact info
    this.businesses = [
      {
        id: 'comp-apex-101',
        owner_id: 'usr-apex-01',
        business_name: 'Apex Technologies Pvt Ltd',
        business_type: 'Software & Cloud Services',
        currency: 'INR',
        description: 'Enterprise enterprise cloud and SaaS development firm delivering mission-critical platforms.',
        website: 'https://apextech.io',
        contact: {
          companyName: 'Apex Technologies Pvt Ltd',
          contactPersonName: 'Rajesh Sharma',
          phoneNumber: '+91 98201 54321',
          emailAddress: 'rajesh.sharma@apextech.io',
          updatedAt: new Date(Date.now() - 5 * 86400000).toISOString(),
        },
        created_at: new Date(Date.now() - 30 * 86400000).toISOString(),
        updated_at: new Date().toISOString(),
      },
      {
        id: 'comp-beacon-202',
        owner_id: 'usr-beacon-02',
        business_name: 'Beacon Creative Studio',
        business_type: 'Design & Branding',
        currency: 'INR',
        description: 'Boutique digital branding agency specializing in visual identity and high-impact UI/UX design.',
        website: 'https://beaconstudio.design',
        contact: {
          companyName: 'Beacon Creative Studio',
          contactPersonName: 'Anita Roy',
          phoneNumber: '+91 98450 11223',
          emailAddress: 'anita.roy@beaconstudio.design',
          updatedAt: new Date(Date.now() - 10 * 86400000).toISOString(),
        },
        created_at: new Date(Date.now() - 45 * 86400000).toISOString(),
        updated_at: new Date().toISOString(),
      },
    ];

    // Historical incomes
    this.incomes = [
      // Company A (Apex) - has historical incomes, but NOTHING for today!
      {
        id: 'inc-apex-1',
        owner_id: 'usr-apex-01',
        business_id: 'comp-apex-101',
        amount: 85000,
        description: 'Monthly Maintenance Contract - Global Corp',
        category: 'Consulting',
        income_date: yesterday,
        created_at: new Date(Date.now() - 86400000).toISOString(),
        updated_at: new Date(Date.now() - 86400000).toISOString(),
      },
      {
        id: 'inc-apex-2',
        owner_id: 'usr-apex-01',
        business_id: 'comp-apex-101',
        amount: 140000,
        description: 'Cloud Migration Milestone 1',
        category: 'Services',
        income_date: new Date(Date.now() - 3 * 86400000).toISOString().split('T')[0],
        created_at: new Date(Date.now() - 3 * 86400000).toISOString(),
        updated_at: new Date(Date.now() - 3 * 86400000).toISOString(),
      },

      // Company B (Beacon) - HAS BOTH INCOME AND PROFIT/EXPENSES LOGGED FOR TODAY!
      {
        id: 'inc-beacon-today',
        owner_id: 'usr-beacon-02',
        business_id: 'comp-beacon-202',
        amount: 65000,
        description: 'Brand Identity Package - Horizon Labs',
        category: 'Design Retainer',
        income_date: today,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      {
        id: 'inc-beacon-hist',
        owner_id: 'usr-beacon-02',
        business_id: 'comp-beacon-202',
        amount: 95000,
        description: 'Website Redesign Phase 2',
        category: 'Web Design',
        income_date: yesterday,
        created_at: new Date(Date.now() - 86400000).toISOString(),
        updated_at: new Date(Date.now() - 86400000).toISOString(),
      },
    ];

    // Expenses
    this.expenses = [
      // Company A
      {
        id: 'exp-apex-1',
        owner_id: 'usr-apex-01',
        business_id: 'comp-apex-101',
        amount: 22000,
        description: 'Server Infrastructure & AWS Cloud',
        category: 'Software',
        expense_date: yesterday,
        created_at: new Date(Date.now() - 86400000).toISOString(),
        updated_at: new Date(Date.now() - 86400000).toISOString(),
      },
      // Company B - has today's expense/profit entry
      {
        id: 'exp-beacon-today',
        owner_id: 'usr-beacon-02',
        business_id: 'comp-beacon-202',
        amount: 14500,
        description: 'Figma and Adobe Creative Cloud Suite',
        category: 'Software',
        expense_date: today,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ];

    // Invoices
    this.invoices = [
      {
        id: 'inv-apex-1001',
        owner_id: 'usr-apex-01',
        business_id: 'comp-apex-101',
        invoice_number: 'INV-2026-001',
        customer_name: 'Nexus Dynamics',
        customer_email: 'billing@nexusdynamics.com',
        subtotal: 75000,
        tax: 13500,
        total: 88500,
        issue_date: yesterday,
        due_date: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
        status: 'Sent',
        notes: 'Payment terms: Net 15 days via NEFT/RTGS',
        items: [
          {
            id: 'item-1',
            invoice_id: 'inv-apex-1001',
            description: 'API Integration & Webhook Architecture',
            quantity: 1,
            unit_price: 75000,
            amount: 75000,
          },
        ],
        created_at: new Date(Date.now() - 86400000).toISOString(),
        updated_at: new Date(Date.now() - 86400000).toISOString(),
      },
      {
        id: 'inv-beacon-2001',
        owner_id: 'usr-beacon-02',
        business_id: 'comp-beacon-202',
        invoice_number: 'INV-2026-108',
        customer_name: 'Starlight Retailers',
        customer_email: 'accounts@starlight.co',
        subtotal: 50000,
        tax: 9000,
        total: 59000,
        issue_date: today,
        due_date: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
        status: 'Paid',
        notes: 'Paid via UPI. Thank you for your business.',
        items: [
          {
            id: 'item-2',
            invoice_id: 'inv-beacon-2001',
            description: 'Brand Guidelines & Vector Assets',
            quantity: 1,
            unit_price: 50000,
            amount: 50000,
          },
        ],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ];

    // Payments
    this.payments = [
      {
        id: 'pay-beacon-1',
        owner_id: 'usr-beacon-02',
        business_id: 'comp-beacon-202',
        invoice_id: 'inv-beacon-2001',
        amount: 59000,
        payment_date: today,
        payment_method: 'UPI',
        notes: 'Transaction ref: UPI-8492019482',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ];

    // Sample reminder log from previous day for testing history
    this.reminderLogs = [
      {
        id: 'rem-sample-prev',
        companyId: 'comp-apex-101',
        companyName: 'Apex Technologies Pvt Ltd',
        date: yesterday,
        recipient: {
          contactPersonName: 'Rajesh Sharma',
          phoneNumber: '+91 98201 54321',
          emailAddress: 'rajesh.sharma@apextech.io',
        },
        channel: 'Multi-Channel (Demo)',
        message:
          "Hello Apex Technologies Pvt Ltd, this is a daily reminder from KUBO Finance. Today's income and profit details have not been updated yet. Please update today's financial details to keep your records accurate.",
        status: 'logged',
        sentAt: new Date(Date.now() - 86400000).toISOString(),
        isDemo: true,
        notes: 'Automated daily check run. Demo Mode: message logged successfully.',
      },
    ];
  }

  // --- Businesses ---
  public getBusinesses(): Business[] {
    return [...this.businesses];
  }

  public getBusinessById(id: string): Business | undefined {
    return this.businesses.find((b) => b.id === id);
  }

  public addBusiness(data: {
    business_name: string;
    business_type: string;
    currency?: string;
    description?: string;
    website?: string;
    contactPersonName?: string;
    phoneNumber?: string;
    emailAddress?: string;
  }): Business {
    const id = `comp-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const newBusiness: Business = {
      id,
      owner_id: `usr-${id}`,
      business_name: data.business_name,
      business_type: data.business_type || 'General Business',
      currency: data.currency || 'INR',
      description: data.description || '',
      website: data.website || '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      contact:
        data.contactPersonName || data.phoneNumber || data.emailAddress
          ? {
              companyName: data.business_name,
              contactPersonName: data.contactPersonName || '',
              phoneNumber: data.phoneNumber || '',
              emailAddress: data.emailAddress || '',
              updatedAt: new Date().toISOString(),
            }
          : undefined,
    };
    this.businesses.unshift(newBusiness);
    return newBusiness;
  }

  public updateBusiness(
    id: string,
    updates: Partial<{
      business_name: string;
      business_type: string;
      currency: string;
      description: string;
      website: string;
    }>,
  ): Business | null {
    const business = this.businesses.find((b) => b.id === id);
    if (!business) return null;

    if (updates.business_name !== undefined) {
      business.business_name = updates.business_name;
      if (business.contact) {
        business.contact.companyName = updates.business_name;
      }
    }
    if (updates.business_type !== undefined) business.business_type = updates.business_type;
    if (updates.currency !== undefined) business.currency = updates.currency;
    if (updates.description !== undefined) business.description = updates.description;
    if (updates.website !== undefined) business.website = updates.website;
    business.updated_at = new Date().toISOString();

    return business;
  }

  public deleteBusiness(id: string): boolean {
    const index = this.businesses.findIndex((b) => b.id === id);
    if (index === -1) return false;

    // Delete company and cascade delete its records safely
    this.businesses.splice(index, 1);
    this.incomes = this.incomes.filter((i) => i.business_id !== id);
    this.expenses = this.expenses.filter((e) => e.business_id !== id);
    this.invoices = this.invoices.filter((inv) => inv.business_id !== id);
    this.payments = this.payments.filter((p) => p.business_id !== id);
    this.reminderLogs = this.reminderLogs.filter((r) => r.companyId !== id);
    return true;
  }

  public updateBusinessContact(id: string, contact: CompanyContact): Business {
    const business = this.businesses.find((b) => b.id === id);
    if (!business) {
      throw new Error(`Company with ID ${id} not found.`);
    }

    business.contact = {
      ...contact,
      updatedAt: new Date().toISOString(),
    };
    business.business_name = contact.companyName;
    business.updated_at = new Date().toISOString();

    return business;
  }

  public deleteBusinessContact(id: string): Business | null {
    const business = this.businesses.find((b) => b.id === id);
    if (!business) return null;
    business.contact = undefined;
    business.updated_at = new Date().toISOString();
    return business;
  }

  // --- Financial Status for a company on a given date ---
  public checkTodayFinancialStatus(
    companyId: string,
    targetDate: string = getTodayDateString(),
  ): DailyFinancialStatus {
    const companyIncomes = this.incomes.filter(
      (inc) => inc.business_id === companyId && inc.income_date === targetDate,
    );
    const companyExpenses = this.expenses.filter(
      (exp) => exp.business_id === companyId && exp.expense_date === targetDate,
    );

    const hasIncome = companyIncomes.length > 0;
    // Today's profit requirement: user must either have entered today's expenses
    // or both income and expense/profit tracking.
    const hasExpensesOrProfit = companyExpenses.length > 0;

    const totalIncomeToday = companyIncomes.reduce((acc, curr) => acc + Number(curr.amount), 0);
    const totalExpenseToday = companyExpenses.reduce((acc, curr) => acc + Number(curr.amount), 0);
    const calculatedProfitToday = totalIncomeToday - totalExpenseToday;

    // Both today's income and profit details are required
    const isFullyUpdated = hasIncome && hasExpensesOrProfit;

    // Check if reminder was already sent today
    const existingReminder = this.reminderLogs.find(
      (r) =>
        r.companyId === companyId &&
        r.date === targetDate &&
        (r.status === 'sent' || r.status === 'logged'),
    );

    return {
      date: targetDate,
      hasIncome,
      hasExpensesOrProfit,
      isFullyUpdated,
      totalIncomeToday,
      totalExpenseToday,
      calculatedProfitToday,
      needsReminder: !isFullyUpdated,
      reminderSentToday: !!existingReminder,
      lastReminderLog: existingReminder,
    };
  }

  // --- Incomes ---
  public getIncomes(companyId: string): IncomeRecord[] {
    return this.incomes.filter((i) => i.business_id === companyId);
  }

  public addIncome(record: Omit<IncomeRecord, 'id' | 'created_at' | 'updated_at'>): IncomeRecord {
    const newRecord: IncomeRecord = {
      ...record,
      id: `inc-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    this.incomes.unshift(newRecord);
    return newRecord;
  }

  public deleteIncome(id: string, companyId: string): boolean {
    const index = this.incomes.findIndex((i) => i.id === id && i.business_id === companyId);
    if (index !== -1) {
      this.incomes.splice(index, 1);
      return true;
    }
    return false;
  }

  public updateIncome(
    id: string,
    companyId: string,
    updates: Partial<{ amount: number; description: string; category: string; income_date: string }>,
  ): IncomeRecord | null {
    const item = this.incomes.find((i) => i.id === id && i.business_id === companyId);
    if (!item) return null;

    if (updates.amount !== undefined) item.amount = Number(updates.amount);
    if (updates.description !== undefined) item.description = updates.description.trim();
    if (updates.category !== undefined) item.category = updates.category.trim();
    if (updates.income_date !== undefined) item.income_date = updates.income_date;
    item.updated_at = new Date().toISOString();
    return item;
  }

  // --- Expenses ---
  public getExpenses(companyId: string): ExpenseRecord[] {
    return this.expenses.filter((e) => e.business_id === companyId);
  }

  public addExpense(record: Omit<ExpenseRecord, 'id' | 'created_at' | 'updated_at'>): ExpenseRecord {
    const newRecord: ExpenseRecord = {
      ...record,
      id: `exp-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    this.expenses.unshift(newRecord);
    return newRecord;
  }

  public deleteExpense(id: string, companyId: string): boolean {
    const index = this.expenses.findIndex((e) => e.id === id && e.business_id === companyId);
    if (index !== -1) {
      this.expenses.splice(index, 1);
      return true;
    }
    return false;
  }

  public updateExpense(
    id: string,
    companyId: string,
    updates: Partial<{ amount: number; description: string; category: string; expense_date: string }>,
  ): ExpenseRecord | null {
    const item = this.expenses.find((e) => e.id === id && e.business_id === companyId);
    if (!item) return null;

    if (updates.amount !== undefined) item.amount = Number(updates.amount);
    if (updates.description !== undefined) item.description = updates.description.trim();
    if (updates.category !== undefined) item.category = updates.category.trim();
    if (updates.expense_date !== undefined) item.expense_date = updates.expense_date;
    item.updated_at = new Date().toISOString();
    return item;
  }

  // --- Invoices ---
  public getInvoices(companyId: string): InvoiceRecord[] {
    return this.invoices.filter((inv) => inv.business_id === companyId);
  }

  public addInvoice(record: Omit<InvoiceRecord, 'id' | 'created_at' | 'updated_at'>): InvoiceRecord {
    const newRecord: InvoiceRecord = {
      ...record,
      id: `inv-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    this.invoices.unshift(newRecord);
    return newRecord;
  }

  public updateInvoice(
    id: string,
    companyId: string,
    updates: Partial<{
      customer_name: string;
      customer_email: string;
      subtotal: number;
      tax: number;
      total: number;
      due_date: string;
      status: InvoiceRecord['status'];
      notes: string;
    }>,
  ): InvoiceRecord | null {
    const inv = this.invoices.find((i) => i.id === id && i.business_id === companyId);
    if (!inv) return null;

    if (updates.customer_name !== undefined) inv.customer_name = updates.customer_name;
    if (updates.customer_email !== undefined) inv.customer_email = updates.customer_email;
    if (updates.subtotal !== undefined) inv.subtotal = Number(updates.subtotal);
    if (updates.tax !== undefined) inv.tax = Number(updates.tax);
    if (updates.total !== undefined) {
      inv.total = Number(updates.total);
    } else if (updates.subtotal !== undefined || updates.tax !== undefined) {
      inv.total = inv.subtotal + inv.tax;
    }
    if (updates.due_date !== undefined) inv.due_date = updates.due_date;
    if (updates.status !== undefined) inv.status = updates.status;
    if (updates.notes !== undefined) inv.notes = updates.notes;
    inv.updated_at = new Date().toISOString();
    return inv;
  }

  public deleteInvoice(id: string, companyId: string): boolean {
    const index = this.invoices.findIndex((inv) => inv.id === id && inv.business_id === companyId);
    if (index !== -1) {
      this.invoices.splice(index, 1);
      return true;
    }
    return false;
  }

  public updateInvoiceStatus(id: string, status: InvoiceRecord['status'], companyId: string): InvoiceRecord | null {
    const inv = this.invoices.find((i) => i.id === id && i.business_id === companyId);
    if (!inv) return null;
    inv.status = status;
    inv.updated_at = new Date().toISOString();
    return inv;
  }

  // --- Payments ---
  public getPayments(companyId: string): PaymentRecord[] {
    return this.payments.filter((p) => p.business_id === companyId);
  }

  public addPayment(record: Omit<PaymentRecord, 'id' | 'created_at' | 'updated_at'>): PaymentRecord {
    const newRecord: PaymentRecord = {
      ...record,
      id: `pay-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    this.payments.unshift(newRecord);

    // If invoice_id exists, check if marked paid
    if (record.invoice_id) {
      const inv = this.invoices.find((i) => i.id === record.invoice_id);
      if (inv) {
        inv.status = 'Paid';
        inv.updated_at = new Date().toISOString();
      }
    }

    return newRecord;
  }

  public deletePayment(id: string, companyId: string): boolean {
    const index = this.payments.findIndex((p) => p.id === id && p.business_id === companyId);
    if (index !== -1) {
      this.payments.splice(index, 1);
      return true;
    }
    return false;
  }

  // Safe data management: clear only financial data belonging strictly to target companyId
  public clearCompanyFinancialData(companyId: string): {
    deletedIncomes: number;
    deletedExpenses: number;
    deletedInvoices: number;
    deletedPayments: number;
  } {
    const initialIncomes = this.incomes.length;
    const initialExpenses = this.expenses.length;
    const initialInvoices = this.invoices.length;
    const initialPayments = this.payments.length;

    this.incomes = this.incomes.filter((i) => i.business_id !== companyId);
    this.expenses = this.expenses.filter((e) => e.business_id !== companyId);
    this.invoices = this.invoices.filter((inv) => inv.business_id !== companyId);
    this.payments = this.payments.filter((p) => p.business_id !== companyId);
    // Also remove reminder logs for this company so it starts completely fresh
    this.reminderLogs = this.reminderLogs.filter((r) => r.companyId !== companyId);

    return {
      deletedIncomes: initialIncomes - this.incomes.length,
      deletedExpenses: initialExpenses - this.expenses.length,
      deletedInvoices: initialInvoices - this.invoices.length,
      deletedPayments: initialPayments - this.payments.length,
    };
  }

  // --- Reminder History (Isolated by company) ---
  public getReminderLogs(companyId?: string): ReminderLog[] {
    if (companyId) {
      return this.reminderLogs
        .filter((r) => r.companyId === companyId)
        .sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());
    }
    return [...this.reminderLogs].sort(
      (a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime(),
    );
  }

  public addReminderLog(log: Omit<ReminderLog, 'id'>): ReminderLog {
    const newLog: ReminderLog = {
      ...log,
      id: `rem-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    };
    this.reminderLogs.unshift(newLog);
    return newLog;
  }

  public hasReminderForDate(companyId: string, date: string): boolean {
    return this.reminderLogs.some(
      (r) =>
        r.companyId === companyId &&
        r.date === date &&
        (r.status === 'sent' || r.status === 'logged'),
    );
  }

  // Reset demo state or clear today's reminder for testing
  public clearTodayReminder(companyId: string, date: string = getTodayDateString()) {
    this.reminderLogs = this.reminderLogs.filter(
      (r) => !(r.companyId === companyId && r.date === date),
    );
  }
}

export const db = new InMemoryKuboDatabase();
