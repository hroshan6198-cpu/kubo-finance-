import { ReminderLog, SchedulerRunResult } from '../src/types';
import { db, getTodayDateString } from './db';
import { buildReminderMessage, messagingService } from './messaging';

export function isValidEmail(email?: string): boolean {
  if (!email) return false;
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email.trim());
}

export function isValidPhone(phone?: string): boolean {
  if (!phone) return false;
  // Allows international + formats, spaces, dashes, brackets, min 7 digits
  const cleaned = phone.replace(/[\s\-().]/g, '');
  const re = /^\+?[0-9]{7,15}$/;
  return re.test(cleaned);
}

/**
 * Execute the Daily Financial Check across all active companies.
 * Can be triggered automatically by cron/timer or manually via API.
 */
export async function executeDailyFinancialCheck(
  targetDate: string = getTodayDateString(),
): Promise<SchedulerRunResult> {
  const runAt = new Date().toISOString();
  console.log(`[KUBO Scheduler] Starting Daily Financial Check for date: ${targetDate} at ${runAt}`);

  const businesses = db.getBusinesses();
  const runLogs: ReminderLog[] = [];
  let remindersProcessed = 0;
  let skippedAlreadyUpdated = 0;
  let skippedAlreadySent = 0;
  let failedCount = 0;

  for (const business of businesses) {
    try {
      const companyId = business.id;
      const companyName = business.business_name || business.contact?.companyName || 'Valued Company';

      // 1. Check Today's Income and Profit records
      const financialStatus = db.checkTodayFinancialStatus(companyId, targetDate);

      // If already updated, do nothing
      if (financialStatus.isFullyUpdated) {
        console.log(
          `[KUBO Scheduler] [Company: ${companyName}] Today's income and profit already recorded. Skipping reminder.`,
        );
        skippedAlreadyUpdated++;

        // Store a lightweight audit note if desired or leave as skipped
        continue;
      }

      // 2. Duplicate prevention: check if reminder already sent/logged today
      if (db.hasReminderForDate(companyId, targetDate)) {
        console.log(
          `[KUBO Scheduler] [Company: ${companyName}] Reminder already processed for ${targetDate}. Skipping duplicate.`,
        );
        skippedAlreadySent++;
        continue;
      }

      // 3. Retrieve company's saved contact information
      const contact = business.contact;
      if (!contact || (!contact.emailAddress && !contact.phoneNumber)) {
        console.warn(
          `[KUBO Scheduler] [Company: ${companyName}] Missing contact information. Cannot dispatch reminder.`,
        );
        failedCount++;
        const failedLog = db.addReminderLog({
          companyId,
          companyName,
          date: targetDate,
          recipient: {
            contactPersonName: contact?.contactPersonName || 'Unknown',
            phoneNumber: contact?.phoneNumber || '',
            emailAddress: contact?.emailAddress || '',
          },
          channel: 'Multi-Channel (Demo)',
          message: buildReminderMessage(companyName),
          status: 'failed_no_contact',
          sentAt: new Date().toISOString(),
          isDemo: true,
          notes: 'Failed: No contact person, phone number or email address found for this company.',
        });
        runLogs.push(failedLog);
        continue;
      }

      // 4. Validate contact phone & email
      const emailValid = isValidEmail(contact.emailAddress);
      const phoneValid = isValidPhone(contact.phoneNumber);

      if (!emailValid && !phoneValid) {
        console.warn(
          `[KUBO Scheduler] [Company: ${companyName}] Invalid contact phone (${contact.phoneNumber}) and email (${contact.emailAddress}).`,
        );
        failedCount++;
        const invalidLog = db.addReminderLog({
          companyId,
          companyName,
          date: targetDate,
          recipient: {
            contactPersonName: contact.contactPersonName,
            phoneNumber: contact.phoneNumber,
            emailAddress: contact.emailAddress,
          },
          channel: 'Multi-Channel (Demo)',
          message: buildReminderMessage(companyName),
          status: 'failed_invalid_contact',
          sentAt: new Date().toISOString(),
          isDemo: true,
          notes: `Failed: Stored contact has invalid phone (${contact.phoneNumber}) and email (${contact.emailAddress}).`,
        });
        runLogs.push(invalidLog);
        continue;
      }

      // 5. Generate Company-Specific Message
      const reminderMessage = buildReminderMessage(companyName);

      // 6. Message Delivery (Demo Mode / Real Provider)
      const deliveryResult = await messagingService.dispatchReminder({
        companyId,
        companyName,
        recipient: {
          contactPersonName: contact.contactPersonName,
          phoneNumber: contact.phoneNumber,
          emailAddress: contact.emailAddress,
        },
        message: reminderMessage,
        channel: 'Multi-Channel (Demo)',
      });

      // 7. Store Reminder History
      const reminderLog = db.addReminderLog({
        companyId,
        companyName,
        date: targetDate,
        recipient: {
          contactPersonName: contact.contactPersonName,
          phoneNumber: contact.phoneNumber,
          emailAddress: contact.emailAddress,
        },
        channel: deliveryResult.channel,
        message: reminderMessage,
        status: deliveryResult.status,
        sentAt: deliveryResult.timestamp,
        isDemo: deliveryResult.isDemo,
        notes: deliveryResult.logSummary,
      });

      remindersProcessed++;
      runLogs.push(reminderLog);
    } catch (err: unknown) {
      // Isolate errors per company: do NOT crash the scheduler or other companies
      const errorMessage = err instanceof Error ? err.message : String(err);
      console.error(
        `[KUBO Scheduler] Error processing reminder for company ${business.id}:`,
        errorMessage,
      );
      failedCount++;
    }
  }

  const result: SchedulerRunResult = {
    runAt,
    date: targetDate,
    totalCompaniesChecked: businesses.length,
    remindersProcessed,
    skippedAlreadyUpdated,
    skippedAlreadySent,
    failedCount,
    logs: runLogs,
  };

  console.info(
    `[KUBO Scheduler] Completed Daily Financial Check for ${targetDate}. Result: ${remindersProcessed} sent/logged, ${skippedAlreadyUpdated} already updated, ${skippedAlreadySent} already sent, ${failedCount} errors.`,
  );

  return result;
}

/**
 * Initialize backend background cron / interval
 */
let schedulerInterval: NodeJS.Timeout | null = null;

export function startBackgroundDailyScheduler() {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
  }

  console.log('[KUBO Scheduler] Initializing daily background scheduler...');

  // Run initial check after a gentle 3-second startup delay
  setTimeout(() => {
    executeDailyFinancialCheck().catch((err) => {
      console.error('[KUBO Scheduler] Startup check error:', err);
    });
  }, 3000);

  // Run daily check every 24 hours (86,400,000 ms)
  // Also checking periodically every hour to handle date roll-overs safely
  schedulerInterval = setInterval(() => {
    executeDailyFinancialCheck().catch((err) => {
      console.error('[KUBO Scheduler] Periodic check error:', err);
    });
  }, 3600000);
}

export function stopBackgroundDailyScheduler() {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
    console.log('[KUBO Scheduler] Background scheduler stopped.');
  }
}
