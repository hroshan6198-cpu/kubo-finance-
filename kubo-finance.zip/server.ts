import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { db, getTodayDateString } from './server/db';
import {
  executeDailyFinancialCheck,
  isValidEmail,
  isValidPhone,
  startBackgroundDailyScheduler,
} from './server/scheduler';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON middleware
  app.use(express.json());

  // --- REST API ROUTES ---

  // Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', product: 'KUBO Finance', timestamp: new Date().toISOString() });
  });

  // Get all companies / active businesses
  app.get('/api/companies', (req: Request, res: Response) => {
    try {
      const companies = db.getBusinesses();
      res.json(companies);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Create new company
  app.post('/api/companies', (req: Request, res: Response) => {
    try {
      const {
        business_name,
        business_type,
        currency,
        description,
        website,
        contactPersonName,
        phoneNumber,
        emailAddress,
      } = req.body;

      if (!business_name || business_name.trim().length === 0) {
        return res.status(400).json({ error: 'Company name is required.' });
      }

      if (phoneNumber && !isValidPhone(phoneNumber)) {
        return res.status(400).json({
          error: 'Please enter a valid phone number (e.g. +91 98201 54321 or 10-15 digits).',
        });
      }

      if (emailAddress && !isValidEmail(emailAddress)) {
        return res.status(400).json({
          error: 'Please enter a valid email address (e.g. contact@example.com).',
        });
      }

      const created = db.addBusiness({
        business_name: business_name.trim(),
        business_type: business_type ? business_type.trim() : 'General Business',
        currency: currency ? currency.trim().toUpperCase() : 'INR',
        description: description ? description.trim() : '',
        website: website ? website.trim() : '',
        contactPersonName: contactPersonName ? contactPersonName.trim() : undefined,
        phoneNumber: phoneNumber ? phoneNumber.trim() : undefined,
        emailAddress: emailAddress ? emailAddress.trim().toLowerCase() : undefined,
      });

      res.status(201).json(created);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Get specific company with contact and today's financial status
  app.get('/api/companies/:id', (req: Request, res: Response) => {
    try {
      const company = db.getBusinessById(req.params.id);
      if (!company) {
        return res.status(404).json({ error: 'Company not found' });
      }
      const todayStatus = db.checkTodayFinancialStatus(company.id);
      res.json({ ...company, todayStatus });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Update company profile
  app.put('/api/companies/:id', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      const { business_name, business_type, currency, description, website } = req.body;

      if (business_name !== undefined && business_name.trim().length === 0) {
        return res.status(400).json({ error: 'Company name cannot be empty.' });
      }

      const updated = db.updateBusiness(companyId, {
        business_name: business_name?.trim(),
        business_type: business_type?.trim(),
        currency: currency?.trim().toUpperCase(),
        description: description?.trim(),
        website: website?.trim(),
      });

      if (!updated) {
        return res.status(404).json({ error: 'Company not found.' });
      }

      res.json(updated);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Delete company and cascade remove scoped data
  app.delete('/api/companies/:id', (req: Request, res: Response) => {
    try {
      const success = db.deleteBusiness(req.params.id);
      if (!success) {
        return res.status(404).json({ error: 'Company not found.' });
      }
      res.json({ success: true, message: 'Company deleted successfully.' });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Update company contact information (with strict validation)
  app.put('/api/companies/:id/contact', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      const { companyName, contactPersonName, phoneNumber, emailAddress } = req.body;

      // Validation
      if (!companyName || companyName.trim().length === 0) {
        return res.status(400).json({ error: 'Company name is required.' });
      }

      if (!contactPersonName || contactPersonName.trim().length === 0) {
        return res.status(400).json({ error: 'Contact person name is required.' });
      }

      if (!phoneNumber || !isValidPhone(phoneNumber)) {
        return res.status(400).json({
          error: 'Please enter a valid phone number (e.g. +91 98201 54321 or 10-15 digits).',
        });
      }

      if (!emailAddress || !isValidEmail(emailAddress)) {
        return res.status(400).json({
          error: 'Please enter a valid email address (e.g. contact@example.com).',
        });
      }

      const updated = db.updateBusinessContact(companyId, {
        companyName: companyName.trim(),
        contactPersonName: contactPersonName.trim(),
        phoneNumber: phoneNumber.trim(),
        emailAddress: emailAddress.trim().toLowerCase(),
        updatedAt: new Date().toISOString(),
      });

      res.json({
        success: true,
        message: 'Company contact updated successfully.',
        company: updated,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Delete company contact (clear contact info)
  app.delete('/api/companies/:id/contact', (req: Request, res: Response) => {
    try {
      const updated = db.deleteBusinessContact(req.params.id);
      if (!updated) {
        return res.status(404).json({ error: 'Company not found.' });
      }
      res.json({
        success: true,
        message: 'Company contact removed successfully.',
        company: updated,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Get financial status for today
  app.get('/api/companies/:id/financial-status', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      const date = (req.query.date as string) || getTodayDateString();
      const status = db.checkTodayFinancialStatus(companyId, date);
      res.json(status);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // --- Incomes ---
  app.get('/api/companies/:id/incomes', (req: Request, res: Response) => {
    try {
      const incomes = db.getIncomes(req.params.id);
      res.json(incomes);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.post('/api/companies/:id/incomes', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      const { amount, description, category, income_date } = req.body;

      if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
        return res.status(400).json({ error: 'Valid income amount is required.' });
      }
      if (!description || description.trim().length === 0) {
        return res.status(400).json({ error: 'Income description is required.' });
      }

      const targetDate = income_date || getTodayDateString();
      const newIncome = db.addIncome({
        owner_id: `usr-${companyId}`,
        business_id: companyId,
        amount: Number(amount),
        description: description.trim(),
        category: category || 'General Revenue',
        income_date: targetDate,
      });

      const todayStatus = db.checkTodayFinancialStatus(companyId, targetDate);

      res.status(201).json({
        success: true,
        income: newIncome,
        todayStatus,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.put('/api/companies/:id/incomes/:incomeId', (req: Request, res: Response) => {
    try {
      const { amount, description, category, income_date } = req.body;
      if (amount !== undefined && (isNaN(Number(amount)) || Number(amount) <= 0)) {
        return res.status(400).json({ error: 'Valid income amount is required.' });
      }
      if (description !== undefined && description.trim().length === 0) {
        return res.status(400).json({ error: 'Income description cannot be empty.' });
      }

      const updated = db.updateIncome(req.params.incomeId, req.params.id, {
        amount: amount !== undefined ? Number(amount) : undefined,
        description,
        category,
        income_date,
      });

      if (!updated) {
        return res.status(404).json({ error: 'Income record not found.' });
      }

      const todayStatus = db.checkTodayFinancialStatus(req.params.id);
      res.json({ success: true, income: updated, todayStatus });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.delete('/api/companies/:id/incomes/:incomeId', (req: Request, res: Response) => {
    try {
      const success = db.deleteIncome(req.params.incomeId, req.params.id);
      const todayStatus = db.checkTodayFinancialStatus(req.params.id);
      res.json({ success, todayStatus });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // --- Expenses ---
  app.get('/api/companies/:id/expenses', (req: Request, res: Response) => {
    try {
      const expenses = db.getExpenses(req.params.id);
      res.json(expenses);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.post('/api/companies/:id/expenses', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      const { amount, description, category, expense_date } = req.body;

      if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
        return res.status(400).json({ error: 'Valid expense amount is required.' });
      }
      if (!description || description.trim().length === 0) {
        return res.status(400).json({ error: 'Expense description is required.' });
      }

      const targetDate = expense_date || getTodayDateString();
      const newExpense = db.addExpense({
        owner_id: `usr-${companyId}`,
        business_id: companyId,
        amount: Number(amount),
        description: description.trim(),
        category: category || 'Other',
        expense_date: targetDate,
      });

      const todayStatus = db.checkTodayFinancialStatus(companyId, targetDate);

      res.status(201).json({
        success: true,
        expense: newExpense,
        todayStatus,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.put('/api/companies/:id/expenses/:expenseId', (req: Request, res: Response) => {
    try {
      const { amount, description, category, expense_date } = req.body;
      if (amount !== undefined && (isNaN(Number(amount)) || Number(amount) <= 0)) {
        return res.status(400).json({ error: 'Valid expense amount is required.' });
      }
      if (description !== undefined && description.trim().length === 0) {
        return res.status(400).json({ error: 'Expense description cannot be empty.' });
      }

      const updated = db.updateExpense(req.params.expenseId, req.params.id, {
        amount: amount !== undefined ? Number(amount) : undefined,
        description,
        category,
        expense_date,
      });

      if (!updated) {
        return res.status(404).json({ error: 'Expense record not found.' });
      }

      const todayStatus = db.checkTodayFinancialStatus(req.params.id);
      res.json({ success: true, expense: updated, todayStatus });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.delete('/api/companies/:id/expenses/:expenseId', (req: Request, res: Response) => {
    try {
      const success = db.deleteExpense(req.params.expenseId, req.params.id);
      const todayStatus = db.checkTodayFinancialStatus(req.params.id);
      res.json({ success, todayStatus });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // --- Invoices & Payments ---
  app.get('/api/companies/:id/invoices', (req: Request, res: Response) => {
    try {
      const invoices = db.getInvoices(req.params.id);
      res.json(invoices);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.post('/api/companies/:id/invoices', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      const { customer_name, customer_email, subtotal, tax, due_date, notes, items } = req.body;

      const numSubtotal = Number(subtotal) || 0;
      const numTax = Number(tax) || 0;
      const numTotal = numSubtotal + numTax;

      const newInvoice = db.addInvoice({
        owner_id: `usr-${companyId}`,
        business_id: companyId,
        invoice_number: `INV-${Date.now().toString().slice(-4)}`,
        customer_name: customer_name || 'Client',
        customer_email,
        subtotal: numSubtotal,
        tax: numTax,
        total: numTotal,
        issue_date: getTodayDateString(),
        due_date: due_date || getTodayDateString(),
        status: 'Sent',
        notes,
        items: items || [
          {
            id: `item-${Date.now()}`,
            invoice_id: '',
            description: 'Financial Services',
            quantity: 1,
            unit_price: numSubtotal,
            amount: numSubtotal,
          },
        ],
      });

      res.status(201).json(newInvoice);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.put('/api/companies/:id/invoices/:invoiceId', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      const invoiceId = req.params.invoiceId;
      const { customer_name, customer_email, subtotal, tax, due_date, status, notes } = req.body;

      const updated = db.updateInvoice(invoiceId, companyId, {
        customer_name,
        customer_email,
        subtotal: subtotal !== undefined ? Number(subtotal) : undefined,
        tax: tax !== undefined ? Number(tax) : undefined,
        due_date,
        status,
        notes,
      });

      if (!updated) {
        return res.status(404).json({ error: 'Invoice not found.' });
      }

      res.json(updated);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.delete('/api/companies/:id/invoices/:invoiceId', (req: Request, res: Response) => {
    try {
      const success = db.deleteInvoice(req.params.invoiceId, req.params.id);
      if (!success) {
        return res.status(404).json({ error: 'Invoice not found.' });
      }
      res.json({ success: true, message: 'Invoice deleted successfully.' });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.get('/api/companies/:id/payments', (req: Request, res: Response) => {
    try {
      const payments = db.getPayments(req.params.id);
      res.json(payments);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.post('/api/companies/:id/payments', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      const { amount, payment_method, invoice_id, notes } = req.body;

      const newPayment = db.addPayment({
        owner_id: `usr-${companyId}`,
        business_id: companyId,
        invoice_id,
        amount: Number(amount) || 0,
        payment_date: getTodayDateString(),
        payment_method: payment_method || 'Bank Transfer',
        notes,
      });

      res.status(201).json(newPayment);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  app.delete('/api/companies/:id/payments/:paymentId', (req: Request, res: Response) => {
    try {
      const success = db.deletePayment(req.params.paymentId, req.params.id);
      if (!success) {
        return res.status(404).json({ error: 'Payment record not found.' });
      }
      res.json({ success: true, message: 'Payment record deleted successfully.' });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Clear financial data for the active company only (safe tenant isolation)
  app.post('/api/companies/:id/clear-financial-data', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      const result = db.clearCompanyFinancialData(companyId);
      const todayStatus = db.checkTodayFinancialStatus(companyId);
      res.json({
        success: true,
        message: 'Financial records cleared safely for this company.',
        summary: result,
        todayStatus,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // --- Reminder History (Isolated by company) ---
  app.get('/api/companies/:id/reminders', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      // Strict isolation: only returns records belonging to companyId
      const reminders = db.getReminderLogs(companyId);
      res.json(reminders);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Helper endpoint to reset/clear today's reminder log for testing duplicate prevention
  app.post('/api/companies/:id/reminders/clear-today', (req: Request, res: Response) => {
    try {
      const companyId = req.params.id;
      db.clearTodayReminder(companyId);
      res.json({ success: true, message: "Cleared today's reminder for testing." });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // Trigger Daily Financial Check (Can be called by scheduler or manual test button)
  app.post('/api/reminders/run-daily-check', async (req: Request, res: Response) => {
    try {
      const date = (req.body.date as string) || getTodayDateString();
      const result = await executeDailyFinancialCheck(date);
      res.json(result);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: msg });
    }
  });

  // --- VITE MIDDLEWARE SETUP ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Start server
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[KUBO Finance] Server running on http://0.0.0.0:${PORT}`);
    // Start the background cron / daily scheduler
    startBackgroundDailyScheduler();
  });
}

startServer().catch((err) => {
  console.error('[KUBO Finance] Failed to start server:', err);
  process.exit(1);
});
